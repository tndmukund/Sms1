package com.mysms.spend

import org.junit.Assert.*
import org.junit.Test

class BrandsTest {
    @Test fun zomatoSpellingsShareOneKey() {
        val k = Periods.vendorKey("Zomato")
        assertEquals(k, Periods.vendorKey("Zomato Media Private Limited"))
        assertEquals(k, Periods.vendorKey("Zomato Money"))
    }

    @Test fun zeptoAndBlinkitSpellingsMerge() {
        val z = Periods.vendorKey("ZEPTO")
        assertEquals(z, Periods.vendorKey("ZEPTO MARKETPLACE PRIVATE LIMITED"))
        assertEquals(z, Periods.vendorKey("ZEPTONOW"))
        assertEquals(z, Periods.vendorKey("- support@zeptonow"))
        val b = Periods.vendorKey("Blinkit")
        assertEquals(b, Periods.vendorKey("BLINKIT COMMERCE PRIVATE LIMITED"))
        assertNotEquals(z, b)
    }

    @Test fun shortWordsDoNotMatchInsideOtherWords() {
        assertNotEquals(Periods.vendorKey("Ola"), Periods.vendorKey("Coca Cola Stall"))
    }
}
