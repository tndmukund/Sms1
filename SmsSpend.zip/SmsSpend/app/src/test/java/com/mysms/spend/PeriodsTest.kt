package com.mysms.spend

import org.junit.Assert.*
import org.junit.Test
import java.time.LocalDate
import java.time.ZoneOffset

class PeriodsTest {

    private val utc = ZoneOffset.UTC

    private fun ms(y: Int, m: Int, d: Int) =
        LocalDate.of(y, m, d).atStartOfDay(utc).toInstant().toEpochMilli()

    private fun txn(
        time: Long,
        amount: Double,
        type: TxnType = TxnType.DEBIT,
        party: String? = null
    ) = Txn(type, amount, "HDFC", "Account", "1234", party, null, time, "Rs.$amount ${party ?: ""}")

    // 26 Oct 2026 is a Monday
    private val all = listOf(
        txn(ms(2026, 10, 27), 100.0, party = "Zomato"),
        txn(ms(2026, 10, 30), 200.0, party = "Uber"),
        txn(ms(2026, 11, 2), 300.0, party = "Amazon"),
        txn(ms(2026, 11, 3), 50.0, TxnType.CREDIT, party = "Refund")
    )

    @Test fun weekly() {
        val g = Periods.group(all, Period.WEEK, utc)
        assertEquals(2, g.size)
        assertEquals(LocalDate.of(2026, 11, 2), g[0].start)   // newest first
        assertEquals(300.0, g[0].totalDebit, 0.001)
        assertEquals(50.0, g[0].totalCredit, 0.001)
        assertEquals("26 Oct – 1 Nov 2026", g[1].label)
        assertEquals(300.0, g[1].totalDebit, 0.001)
    }

    @Test fun monthly() {
        val g = Periods.group(all, Period.MONTH, utc)
        assertEquals(listOf("November 2026", "October 2026"), g.map { it.label })
    }

    @Test fun yearly() {
        val g = Periods.group(all, Period.YEAR, utc)
        assertEquals(1, g.size)
        assertEquals("2026", g[0].label)
        assertEquals(600.0, g[0].totalDebit, 0.001)
        assertEquals(4, g[0].count)
    }

    @Test fun searchByMerchantAndAmount() {
        val zomato = all[0]
        val uber = all[1]
        assertTrue(Periods.matches(zomato, "zomato"))
        assertFalse(Periods.matches(uber, "zomato"))
        assertTrue(Periods.matches(uber, ">150"))
        assertFalse(Periods.matches(zomato, ">150"))
        assertTrue(Periods.matches(zomato, "hdfc 1234 <150"))
        assertTrue(Periods.matches(zomato, ""))
    }

    @Test
    fun merchantTotalsAreGroupedAndSortedBySpend() {
        val list = listOf(
            txn(ms(2026, 10, 27), 100.0, party = "Zomato"),
            txn(ms(2026, 10, 28), 50.0, party = "ZOMATO"),
            txn(ms(2026, 10, 29), 500.0, party = "Uber"),
            txn(ms(2026, 10, 30), 70.0, TxnType.CREDIT, party = "Refund Co")
        )
        val m = Periods.merchants(list)
        assertEquals("Uber", m[0].name)
        assertEquals(150.0, m.first { it.name.equals("zomato", true) }.spent, 0.001)
        assertEquals(2, m.first { it.name.equals("zomato", true) }.count)
        assertEquals(70.0, m.first { it.name == "Refund Co" }.credited, 0.001)
    }

    @Test
    fun vendorsMergeTruncatedAndUpiNames() {
        val list = listOf(
            txn(ms(2026, 10, 27), 100.0, party = "IBIS BENGALU"),
            txn(ms(2026, 10, 28), 50.0, party = "IBIS BENGALURU"),
            txn(ms(2026, 10, 29), 20.0, party = "zomato@icici"),
            txn(ms(2026, 10, 30), 30.0, party = "ZOMATO"),
            txn(ms(2026, 10, 30), 5.0, party = null)
        )
        val v = Periods.vendors(list)
        assertEquals(2, v.size)
        assertEquals("IBIS BENGALURU", v[0].name)
        assertEquals(150.0, v[0].spent, 0.001)
        assertEquals(50.0, v[1].spent, 0.001)
    }

    @Test
    fun groupTotalsMergeSeveralVendors() {
        val list = listOf(
            txn(ms(2026, 10, 27), 100.0, party = "Om Sai Store"),
            txn(ms(2026, 10, 28), 200.0, party = "Om Sai Ram Store"),
            txn(ms(2026, 10, 29), 300.0, party = "Zomato")
        )
        val keys = setOf(Periods.vendorKey("Om Sai Store")!!, Periods.vendorKey("Om Sai Ram Store")!!)
        val g = Periods.groupTotals(list, mapOf("Om Sai shop" to keys)).single()
        assertEquals(300.0, g.spent, 0.001)
        assertEquals(2, g.count)
        assertTrue(g.isGroup)
    }
}
