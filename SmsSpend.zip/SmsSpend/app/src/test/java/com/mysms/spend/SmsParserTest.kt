package com.mysms.spend

import org.junit.Assert.*
import org.junit.Test

class SmsParserTest {

    private fun sms(sender: String, body: String) = RawSms(sender, body, 1_700_000_000_000)

    @Test fun hdfcDebit() {
        val t = SmsParser.parse(sms("AD-HDFCBK",
            "Rs.1,250.00 debited from A/c XX1234 on 12-10-26 to VPA zomato@icici. Avl bal Rs.8,400.50"))!!
        assertEquals(TxnType.DEBIT, t.type)
        assertEquals(1250.0, t.amount, 0.001)
        assertEquals("HDFC", t.bank)
        assertEquals("1234", t.last4)
        assertEquals(8400.5, t.balance!!, 0.001)
    }

    @Test fun creditCardSpend() {
        val t = SmsParser.parse(sms("VM-ICICIT",
            "INR 3,499.00 spent on ICICI Bank Credit Card XX5678 at AMAZON on 10-Oct-26."))!!
        assertEquals(TxnType.DEBIT, t.type)
        assertEquals("Credit Card", t.accountKind)
        assertEquals("5678", t.last4)
    }

    @Test fun salaryCredit() {
        val t = SmsParser.parse(sms("VK-SBIINB",
            "Your a/c no. XXXXXX4321 is credited by Rs.85,000.00 on 01-10-26 salary. Avl Bal Rs.92,100.00"))!!
        assertEquals(TxnType.CREDIT, t.type)
        assertEquals(85000.0, t.amount, 0.001)
        assertEquals("SBI", t.bank)
    }

    @Test fun otpIgnored() {
        assertNull(SmsParser.parse(sms("AD-HDFCBK", "123456 is your OTP for txn of Rs.500. Do not share.")))
    }

    @Test fun promoIgnored() {
        assertNull(SmsParser.parse(sms("AX-AXISBK", "Pre-approved loan offer up to Rs.5,00,000. Apply now.")))
    }
}
