package com.mysms.spend

/**
 * Turns bank / card / UPI SMS text into [Txn] objects.
 * Pure Kotlin (no Android classes) so it can be unit tested on the JVM.
 *
 * Indian bank SMS formats vary a lot, so this is rule based:
 *  1. skip OTPs, promos and requests
 *  2. decide debit vs credit from keywords
 *  3. pull amount, account/card digits, merchant, balance with regexes
 *  4. join messages that belong to the same bank account ([normalize])
 *
 * When a message from your bank is mis-read, add its wording to the keyword
 * lists or regexes below.
 */
object SmsParser {

    private val debitWords = listOf(
        "debited", "spent", "withdrawn", "purchase of", "paid to", "paid at",
        "sent to", "payment of", "txn of", "transaction of", "charged", "debit alert"
    )
    private val creditWords = listOf(
        "credited", "received", "deposited", "refund", "reversed", "cashback",
        "credit alert", "salary"
    )
    private val skipWords = listOf(
        "otp", "one time password", "one-time password", "verification code",
        "will be debited", "to be debited", "request", "requested", "mandate",
        "due on", "due date", "minimum amount due", "statement", "offer",
        "apply now", "pre-approved", "click", "http", "kyc", "failed", "declined"
    )

    private val amountRe = Regex(
        """(?:rs\.?|inr|₹)\s*([0-9][0-9,]*(?:\.[0-9]{1,2})?)""",
        RegexOption.IGNORE_CASE
    )
    private val balanceRe = Regex(
        """(?:avl|avail|available|bal|balance)[^0-9₹]{0,25}(?:rs\.?|inr|₹)?\s*([0-9][0-9,]*(?:\.[0-9]{1,2})?)""",
        RegexOption.IGNORE_CASE
    )
    private val last4Re = Regex(
        """(?:a/c|acct|account|card|ac)\D{0,12}?(?:x+|\*+|ending|no\.?)?\s*[xX*]*([0-9]{3,4})\b""",
        RegexOption.IGNORE_CASE
    )
    private val maskedRe = Regex("""[xX*]{2,}\s*([0-9]{3,4})\b""")
    private val partyRe = Regex(
        """(?:\bat\b|\bto\b|\bfrom\b|\binfo:?|\bvpa\b|\btowards\b)\s+([A-Za-z0-9@._&\- ]{3,35}?)(?=\s+(?:on|ref|upi|txn|avl|bal|via|using|\.|,)|[.,]|$)""",
        RegexOption.IGNORE_CASE
    )

    // Matched against the sender id, e.g. "AD-HDFCBK", "VM-SBYONO-S", "JM-HSBCIN-S"
    private val bankBySender = linkedMapOf(
        "HDFC" to "HDFC", "SBI" to "SBI", "YONO" to "SBI", "ICICI" to "ICICI",
        "AXIS" to "Axis", "KOTAK" to "Kotak", "PNB" to "PNB", "BOB" to "Bank of Baroda",
        "CANARA" to "Canara", "UNION" to "Union Bank", "IDFC" to "IDFC First",
        "INDUS" to "IndusInd", "YES" to "Yes Bank", "SCB" to "Standard Chartered",
        "CITI" to "Citi", "AMEX" to "Amex", "PAYTM" to "Paytm", "PHONEPE" to "PhonePe",
        "AMAZON" to "Amazon Pay", "BOI" to "Bank of India", "IOB" to "IOB",
        "FEDERAL" to "Federal", "RBL" to "RBL", "HSBC" to "HSBC", "PLUXEE" to "Pluxee",
        "ONECARD" to "OneCard", "AU" to "AU Small Finance"
    )

    fun parse(sms: RawSms): Txn? {
        val text = sms.body.replace("\n", " ").replace(Regex("\\s+"), " ").trim()
        val lower = text.lowercase()

        if (skipWords.any { lower.contains(it) }) return null

        val hasDebit = debitWords.any { lower.contains(it) } ||
            Regex("""\bdr\b""").containsMatchIn(lower)
        val hasCredit = creditWords.any { lower.contains(it) } ||
            Regex("""\bcr\b""").containsMatchIn(lower)
        if (!hasDebit && !hasCredit) return null

        // If both appear, whichever keyword shows up first wins ("debited ... credited to X")
        val type = when {
            hasDebit && !hasCredit -> TxnType.DEBIT
            hasCredit && !hasDebit -> TxnType.CREDIT
            else -> {
                val d = debitWords.mapNotNull { lower.indexOf(it).takeIf { i -> i >= 0 } }.minOrNull() ?: Int.MAX_VALUE
                val c = creditWords.mapNotNull { lower.indexOf(it).takeIf { i -> i >= 0 } }.minOrNull() ?: Int.MAX_VALUE
                if (d <= c) TxnType.DEBIT else TxnType.CREDIT
            }
        }

        val balance = balanceRe.find(text)?.let { toAmount(it.groupValues[1]) }

        // First amount that is not the balance figure
        val amount = amountRe.findAll(text)
            .map { toAmount(it.groupValues[1]) }
            .firstOrNull { it != null && it != balance }
            ?: return null
        if (amount <= 0.0) return null

        val last4 = last4Re.find(text)?.groupValues?.get(1)
            ?: maskedRe.find(text)?.groupValues?.get(1)

        val kind = when {
            lower.contains("credit card") || Regex("""\bcc\b""").containsMatchIn(lower) -> "Credit Card"
            lower.contains("debit card") || lower.contains("atm") -> "Debit Card"
            lower.contains("card") -> "Card"
            lower.contains("upi") || lower.contains("wallet") || lower.contains("vpa") -> "UPI/Wallet"
            else -> "Account"
        }

        val party = partyRe.find(text)?.groupValues?.get(1)?.trim()
            ?.takeIf { it.length >= 3 && !it.equals("a/c", true) }

        return Txn(
            type = type,
            amount = amount,
            bank = bankFromSender(sms.sender),
            accountKind = kind,
            last4 = last4,
            party = party,
            balance = balance,
            timeMillis = sms.timeMillis,
            raw = text,
            sender = sms.sender,
            smsId = sms.id,
            threadId = sms.threadId
        )
    }

    fun parseAll(list: List<RawSms>): List<Txn> = normalize(list.mapNotNull { parse(it) })

    /**
     * Joins messages of the same bank account. Some SMS carry the last digits and some do not.
     * When a bank has only ONE account (or only one credit card) with known digits,
     * the messages without digits are added to it.
     */
    fun normalize(txns: List<Txn>): List<Txn> {
        fun group(t: Txn) = t.bank + "|" + t.isCreditCard
        val digitsByGroup = txns
            .filter { it.last4 != null }
            .groupBy { group(it) }
            .mapValues { (_, list) -> list.mapNotNull { it.last4 }.distinct() }

        return txns.map { t ->
            if (t.last4 == null) {
                val known = digitsByGroup[group(t)]
                if (known != null && known.size == 1) t.copy(last4 = known[0]) else t
            } else t
        }
    }

    fun summarize(txns: List<Txn>): List<AccountSummary> =
        txns.groupBy { it.accountKey }
            .map { (key, items) ->
                val sorted = items.sortedByDescending { it.timeMillis }
                AccountSummary(
                    key = key,
                    totalDebit = items.filter { it.type == TxnType.DEBIT }.sumOf { it.amount },
                    totalCredit = items.filter { it.type == TxnType.CREDIT }.sumOf { it.amount },
                    count = items.size,
                    lastBalance = sorted.firstOrNull { it.balance != null }?.balance,
                    txns = sorted
                )
            }
            .sortedByDescending { it.totalDebit + it.totalCredit }

    private fun bankFromSender(sender: String): String {
        // "AD-HDFCBK" -> HDFCBK, "VM-SBYONO-S" -> SBYONO (the part after the first dash)
        val parts = sender.uppercase().split('-')
        val id = (if (parts.size >= 2) parts[1] else parts[0]).trim()
        return bankBySender.entries.firstOrNull { id.contains(it.key) }?.value
            ?: id.lowercase().replaceFirstChar { it.uppercase() }.ifBlank { "Unknown" }
    }

    private fun toAmount(s: String): Double? = s.replace(",", "").toDoubleOrNull()
}
