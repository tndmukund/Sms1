package com.mysms.spend

import java.util.Locale

/**
 * Built-in list of well known shops and apps. Every spelling a bank SMS uses for the same brand
 * ("Zomato", "Zomato Media Private Limited", "Zomato Money", "support@zomato" ...) lands in ONE vendor,
 * so nobody has to merge them by hand.
 */
object Brands {
    const val PREFIX = "brand:"

    /** Brand name shown in the app, then the words that identify it inside the SMS merchant name. */
    private val list: List<Pair<String, List<String>>> = listOf(
        "Zomato" to listOf("zomato"),
        "Blinkit" to listOf("blinkit", "grofers"),
        "Zepto" to listOf("zepto"),
        "Swiggy" to listOf("swiggy", "instamart"),
        "BigBasket" to listOf("bigbasket"),
        "Dunzo" to listOf("dunzo"),
        "Amazon" to listOf("amazon", "amzn"),
        "Flipkart" to listOf("flipkart"),
        "Myntra" to listOf("myntra"),
        "Ajio" to listOf("ajio"),
        "Nykaa" to listOf("nykaa"),
        "Meesho" to listOf("meesho"),
        "Uber" to listOf("uber"),
        "Ola" to listOf("ola", "olacabs"),
        "Rapido" to listOf("rapido"),
        "IRCTC" to listOf("irctc"),
        "MakeMyTrip" to listOf("makemytrip", "mmt"),
        "Goibibo" to listOf("goibibo"),
        "IndiGo" to listOf("indigo", "interglobe"),
        "Ibis" to listOf("ibis"),
        "Paytm" to listOf("paytm"),
        "PhonePe" to listOf("phonepe"),
        "MobiKwik" to listOf("mobikwik"),
        "BookMyShow" to listOf("bookmyshow"),
        "Netflix" to listOf("netflix"),
        "Spotify" to listOf("spotify"),
        "Google" to listOf("google"),
        "Apple" to listOf("apple", "itunes"),
        "Airtel" to listOf("airtel"),
        "Jio" to listOf("jio", "jiomart"),
        "Domino's" to listOf("dominos", "jubilant"),
        "McDonald's" to listOf("mcdonalds", "mcdonald", "hardcastle"),
        "KFC" to listOf("kfc"),
        "Starbucks" to listOf("starbucks"),
        "DMart" to listOf("dmart", "avenue"),
        "Decathlon" to listOf("decathlon"),
        "Zerodha" to listOf("zerodha"),
        "Groww" to listOf("groww"),
        "CRED" to listOf("cred"),
        "Indian Oil" to listOf("indianoil"),
        "HP Petrol" to listOf("hpcl", "hindustanpetroleum"),
        "Bharat Petroleum" to listOf("bpcl", "bharatpetroleum")
    )

    private val byKey: Map<String, String> = list.associate { (PREFIX + it.first.uppercase(Locale.ENGLISH)) to it.first }

    /** "brand:ZOMATO" for any Zomato spelling, or null when the name is not a known brand. */
    fun keyFor(party: String?): String? {
        if (party == null) return null
        val words = party.uppercase(Locale.ENGLISH).split(Regex("[^A-Z0-9]+")).filter { it.isNotEmpty() }
        if (words.isEmpty()) return null
        for ((name, keywords) in list) {
            for (kw in keywords) {
                val k = kw.uppercase(Locale.ENGLISH)
                // very short words must match exactly (so "OLA" never matches "COLA" or "OLAM")
                val hit = words.any { w -> if (k.length <= 4) w == k else w.startsWith(k) }
                if (hit) return PREFIX + name.uppercase(Locale.ENGLISH)
            }
        }
        return null
    }

    fun nameOf(key: String): String? = byKey[key]
}
