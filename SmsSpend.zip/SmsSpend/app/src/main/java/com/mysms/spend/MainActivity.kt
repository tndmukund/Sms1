package com.mysms.spend

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.KeyboardArrowLeft
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SpendTheme {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    Box(Modifier.fillMaxSize().systemBarsPadding()) { App() }
                }
            }
        }
    }
}

private val inr: NumberFormat = NumberFormat.getCurrencyInstance(Locale("en", "IN"))
private val inr0: NumberFormat = NumberFormat.getCurrencyInstance(Locale("en", "IN")).apply {
    maximumFractionDigits = 0
    minimumFractionDigits = 0
}
private val dateFmt = SimpleDateFormat("dd MMM yy, hh:mm a", Locale.getDefault())
private val RED = Color(0xFFE5484D)
private val GREEN = Color(0xFF12A150)
private val AVATAR_COLORS = listOf(
    Color(0xFF4F46E5), Color(0xFF0EA5E9), Color(0xFF14B8A6),
    Color(0xFFF59E0B), Color(0xFFEC4899), Color(0xFF8B5CF6)
)

/** Whole rupees in lakh/crore grouping; very large amounts shown in crore. */
private fun money(v: Double): String =
    if (abs(v) >= 10_000_000.0)
        String.format(Locale.ENGLISH, "%s₹%.2f Cr", if (v < 0) "-" else "", abs(v) / 10_000_000.0)
    else inr0.format(v)

@Composable
fun App() {
    val ctx = LocalContext.current
    var granted by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_SMS) ==
                PackageManager.PERMISSION_GRANTED
        )
    }
    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted = it }

    if (!granted) {
        Column(
            Modifier.fillMaxSize().padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("SMS Spend", style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.height(12.dp))
            Text("This app reads your bank SMS on this phone only, to total your spends and credits. Nothing is uploaded.")
            Spacer(Modifier.height(20.dp))
            Button(onClick = { launcher.launch(Manifest.permission.READ_SMS) }) {
                Text("Allow SMS access")
            }
        }
        return
    }

    var all by remember { mutableStateOf<List<Txn>?>(null) }
    LaunchedEffect(Unit) {
        all = withContext(Dispatchers.IO) { SmsParser.parseAll(SmsReader.readInbox(ctx)) }
    }

    val txns = all
    if (txns == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
    } else {
        SummaryScreen(txns)
    }
}

@Composable
private fun SummaryScreen(all: List<Txn>) {
    var period by remember { mutableStateOf(Period.MONTH) }
    var periodIdx by remember { mutableStateOf(0) }          // 0 = latest period
    var query by remember { mutableStateOf("") }
    var typeFilter by remember { mutableStateOf<TxnType?>(null) }
    var largestFirst by remember { mutableStateOf(false) }
    var openAccount by remember { mutableStateOf<String?>(null) }
    var accountSel by remember { mutableStateOf<String?>(null) }   // null = all accounts / cards
    var vendorSel by remember { mutableStateOf<String?>(null) }    // Periods.vendorKey, null = all vendors
    var openTxn by remember { mutableStateOf<Long?>(null) }

    val accountKeys = remember(all) {
        all.groupBy { it.accountKey }.entries.sortedByDescending { it.value.size }.map { it.key }
    }
    val vendorList = remember(all, accountSel) {
        Periods.vendors(all.filter { accountSel == null || it.accountKey == accountSel })
    }
    val vendorName = vendorSel?.let { k -> vendorList.firstOrNull { it.key == k }?.name ?: k }
    val filtered = remember(all, query, typeFilter, accountSel, vendorSel) {
        all.filter {
            (accountSel == null || it.accountKey == accountSel) &&
                (vendorSel == null || Periods.vendorKey(it.party) == vendorSel) &&
                (typeFilter == null || it.type == typeFilter) && Periods.matches(it, query)
        }
    }
    val groups = remember(filtered, period) { Periods.group(filtered, period) }
    val idx = periodIdx.coerceIn(0, maxOf(groups.size - 1, 0))
    val current = groups.getOrNull(idx)

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Column(Modifier.padding(top = 4.dp)) {
                Text("SMS Spend", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Text(
                    "Your bank SMS, summed up on this phone",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        item {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it; openAccount = null; openTxn = null },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = MaterialTheme.colorScheme.surface,
                    unfocusedContainerColor = MaterialTheme.colorScheme.surface,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant
                ),
                label = { Text("Search SMS (zomato, 409, >5000)") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                trailingIcon = {
                    if (query.isNotEmpty()) {
                        IconButton(onClick = { query = "" }) {
                            Icon(Icons.Default.Close, contentDescription = "Clear")
                        }
                    }
                }
            )
        }

        // Filters as dropdowns (account one has a search box)
        item {
            FilterDropdown(
                label = "Card / account",
                valueText = accountSel ?: "All cards & accounts",
                options = listOf<String?>(null) + accountKeys,
                optionText = { it ?: "All cards & accounts" },
                searchable = true,
                onSelect = { accountSel = it; periodIdx = 0; openAccount = null; openTxn = null },
                modifier = Modifier.fillMaxWidth()
            )
        }
        item {
            FilterDropdown(
                label = "Vendor / merchant",
                valueText = vendorName ?: "All vendors",
                options = listOf<VendorTotal?>(null) + vendorList,
                optionText = {
                    if (it == null) "All vendors"
                    else "${it.name} · ${money(it.spent)}" +
                        (if (it.credited > 0) " (+${money(it.credited)})" else "") + " · ${it.count} SMS"
                },
                searchable = true,
                searchHint = "Search vendor e.g. zepto, ibis",
                onSelect = { vendorSel = it?.key; periodIdx = 0; openAccount = null; openTxn = null },
                modifier = Modifier.fillMaxWidth()
            )
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterDropdown(
                    label = "Period",
                    valueText = period.title,
                    options = Period.values().toList(),
                    optionText = { it.title },
                    searchable = false,
                    onSelect = { period = it; periodIdx = 0; openAccount = null; openTxn = null },
                    modifier = Modifier.weight(1f)
                )
                FilterDropdown(
                    label = "Show",
                    valueText = when (typeFilter) { TxnType.DEBIT -> "Spent"; TxnType.CREDIT -> "Credited"; null -> "All" },
                    options = listOf<TxnType?>(null, TxnType.DEBIT, TxnType.CREDIT),
                    optionText = { when (it) { TxnType.DEBIT -> "Spent only"; TxnType.CREDIT -> "Credited only"; null -> "All" } },
                    searchable = false,
                    onSelect = { typeFilter = it; openAccount = null; openTxn = null },
                    modifier = Modifier.weight(1f)
                )
                FilterDropdown(
                    label = "Sort",
                    valueText = if (largestFirst) "Largest" else "Newest",
                    options = listOf(false, true),
                    optionText = { if (it) "Largest first" else "Newest first" },
                    searchable = false,
                    onSelect = { largestFirst = it },
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // < older   26 Oct – 1 Nov 2026   newer >
        if (period != Period.ALL && groups.isNotEmpty() && current != null) {
            item {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = { periodIdx = idx + 1; openAccount = null; openTxn = null },
                        enabled = idx < groups.size - 1
                    ) { Icon(Icons.Default.KeyboardArrowLeft, contentDescription = "Older") }
                    Text(
                        current.label,
                        modifier = Modifier.weight(1f),
                        textAlign = TextAlign.Center,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    IconButton(
                        onClick = { periodIdx = idx - 1; openAccount = null; openTxn = null },
                        enabled = idx > 0
                    ) { Icon(Icons.Default.KeyboardArrowRight, contentDescription = "Newer") }
                }
            }
        }

        if (current == null) {
            item { Text("No matching bank messages.") }
        } else {
            // Total for the selected period
            item {
                Box(
                    Modifier.fillMaxWidth()
                        .clip(RoundedCornerShape(24.dp))
                        .background(Brush.linearGradient(listOf(Color(0xFF4338CA), Color(0xFF7C3AED))))
                        .padding(20.dp)
                ) {
                    Column {
                        Text(
                            (accountSel ?: "All cards & accounts") + (vendorName?.let { " · $it" } ?: ""),
                            color = Color.White.copy(alpha = 0.85f),
                            style = MaterialTheme.typography.labelLarge,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            current.label,
                            color = Color.White,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(Modifier.height(14.dp))
                        val net = current.totalCredit - current.totalDebit
                        Text("Net", color = Color.White.copy(alpha = 0.75f), style = MaterialTheme.typography.labelMedium)
                        Text(
                            (if (net > 0) "+" else "") + money(net),
                            color = Color.White,
                            fontFamily = PoppinsFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 32.sp,
                            maxLines = 1,
                            softWrap = false
                        )
                        Spacer(Modifier.height(14.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            HeroStat("Spent", money(current.totalDebit), Color(0xFFFFB4B8), Modifier.weight(1f))
                            HeroStat("Credited", money(current.totalCredit), Color(0xFF86F0B2), Modifier.weight(1f))
                        }
                        Text(
                            "${current.count} SMS · ${current.accounts.size} accounts",
                            color = Color.White.copy(alpha = 0.7f),
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.padding(top = 12.dp)
                        )
                    }
                }
            }

            if (accountSel != null) {
                // Where the money went this period, by merchant
                val merchants = Periods.merchants(current.txns)
                item {
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp)) {
                            Text("By merchant · ${current.label}", fontWeight = FontWeight.SemiBold)
                            Spacer(Modifier.height(8.dp))
                            merchants.take(15).forEach { m ->
                                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                                    Column(Modifier.weight(1f)) {
                                        Text(m.name, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        Text(
                                            "${m.count} SMS",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    Column(horizontalAlignment = Alignment.End) {
                                        if (m.spent > 0) Text("- " + inr.format(m.spent), color = RED, maxLines = 1, softWrap = false)
                                        if (m.credited > 0) Text("+ " + inr.format(m.credited), color = GREEN, maxLines = 1, softWrap = false)
                                    }
                                }
                                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                            }
                            if (merchants.size > 15) {
                                Text("+ ${merchants.size - 15} more merchants", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
                // Same card across all weeks / months: tap a row to jump to it
                if (period != Period.ALL) {
                    item {
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(16.dp)) {
                                Text("${period.title} history", fontWeight = FontWeight.SemiBold)
                                Spacer(Modifier.height(8.dp))
                                groups.forEachIndexed { i, g ->
                                    Row(
                                        Modifier.fillMaxWidth().clickable { periodIdx = i; openTxn = null }.padding(vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            g.label,
                                            modifier = Modifier.weight(1.3f),
                                            fontWeight = if (i == idx) FontWeight.Bold else FontWeight.Normal,
                                            style = MaterialTheme.typography.bodySmall
                                        )
                                        Text(money(g.totalDebit), color = RED, modifier = Modifier.weight(1f), textAlign = TextAlign.End, maxLines = 1, softWrap = false, style = MaterialTheme.typography.bodySmall)
                                        Text(money(g.totalCredit), color = GREEN, modifier = Modifier.weight(1f), textAlign = TextAlign.End, maxLines = 1, softWrap = false, style = MaterialTheme.typography.bodySmall)
                                    }
                                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                                }
                                Text(
                                    "Red = spent, green = credited",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(top = 6.dp)
                                )
                            }
                        }
                    }
                }
            }

            item {
                Text(
                    "By bank account",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }

            items(current.accounts, key = { it.key }) { a ->
                AccountCard(
                    a = a,
                    expanded = openAccount == a.key,
                    onToggle = { openAccount = if (openAccount == a.key) null else a.key; openTxn = null },
                    largestFirst = largestFirst,
                    openTxn = openTxn,
                    onOpenTxn = { openTxn = it }
                )
            }
        }
    }
}

/** A dropdown button; with [searchable] the menu starts with a search box. */
@Composable
private fun <T> FilterDropdown(
    label: String,
    valueText: String,
    options: List<T>,
    optionText: (T) -> String,
    searchable: Boolean,
    onSelect: (T) -> Unit,
    modifier: Modifier = Modifier,
    searchHint: String = "Search e.g. amex, hsbc, 7208"
) {
    var expanded by remember { mutableStateOf(false) }
    var q by remember { mutableStateOf("") }
    Box(modifier) {
        OutlinedButton(
            onClick = { expanded = true },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.outlinedButtonColors(containerColor = MaterialTheme.colorScheme.surface),
            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp)
        ) {
            Column(Modifier.weight(1f)) {
                Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(valueText, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
            }
            Icon(Icons.Default.ArrowDropDown, contentDescription = null)
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false; q = "" }) {
            if (searchable) {
                OutlinedTextField(
                    value = q,
                    onValueChange = { q = it },
                    singleLine = true,
                    placeholder = { Text(searchHint) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    modifier = Modifier.padding(horizontal = 8.dp).fillMaxWidth()
                )
            }
            val shown = options.filter { q.isBlank() || optionText(it).contains(q.trim(), ignoreCase = true) }
            if (shown.isEmpty()) {
                DropdownMenuItem(text = { Text("No match") }, onClick = {}, enabled = false)
            }
            shown.forEach { o ->
                DropdownMenuItem(
                    text = { Text(optionText(o)) },
                    onClick = { onSelect(o); expanded = false; q = "" }
                )
            }
        }
    }
}

@Composable
private fun HeroStat(label: String, value: String, tint: Color, modifier: Modifier) {
    Column(
        modifier
            .clip(RoundedCornerShape(16.dp))
            .background(Color.White.copy(alpha = 0.14f))
            .padding(horizontal = 12.dp, vertical = 10.dp)
    ) {
        Text(label, color = Color.White.copy(alpha = 0.8f), style = MaterialTheme.typography.labelMedium)
        Text(
            value, color = tint, fontFamily = PoppinsFamily, fontWeight = FontWeight.Bold,
            fontSize = 17.sp, maxLines = 1, softWrap = false
        )
    }
}

/** Round coloured badge with the bank's first letter. */
@Composable
private fun Avatar(key: String) {
    val color = AVATAR_COLORS[(key.substringBefore(' ').hashCode() and 0x7fffffff) % AVATAR_COLORS.size]
    Box(
        Modifier.size(40.dp).clip(CircleShape).background(color),
        contentAlignment = Alignment.Center
    ) {
        Text(
            key.first().uppercase(),
            color = Color.White,
            fontFamily = PoppinsFamily,
            fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.titleMedium
        )
    }
}

/** Three equal columns: Spent | Credited | Net. Used for the total and for every account, so they line up. */
@Composable
private fun AmountCols(spent: Double, credited: Double) {
    val net = credited - spent
    Row(Modifier.fillMaxWidth()) {
        AmountCell("Spent", money(spent), RED, Modifier.weight(1f))
        AmountCell("Credited", money(credited), GREEN, Modifier.weight(1f))
        AmountCell(
            "Net",
            (if (net > 0) "+" else "") + money(net),
            if (net >= 0) GREEN else RED,
            Modifier.weight(1f)
        )
    }
}

@Composable
private fun AmountCell(label: String, value: String, color: Color, modifier: Modifier) {
    Column(modifier) {
        Text(
            label,
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            value,
            color = color,
            fontFamily = PoppinsFamily,
            fontWeight = FontWeight.SemiBold,
            style = MaterialTheme.typography.bodyMedium,
            maxLines = 1,
            softWrap = false
        )
    }
}

@Composable
private fun AccountCard(
    a: AccountSummary,
    expanded: Boolean,
    onToggle: () -> Unit,
    largestFirst: Boolean,
    openTxn: Long?,
    onOpenTxn: (Long?) -> Unit
) {
    var limit by remember(a.key) { mutableStateOf(30) }
    val isCard = a.key.contains("Credit Card")

    Card(Modifier.fillMaxWidth()) {
        Column {
            Column(Modifier.fillMaxWidth().clickable(onClick = onToggle).padding(16.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Avatar(a.key)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            a.key,
                            fontWeight = FontWeight.SemiBold,
                            style = MaterialTheme.typography.titleSmall,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            (if (isCard) "Credit card" else "Bank account") + " · ${a.count} SMS",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Spacer(Modifier.height(10.dp))
                AmountCols(a.totalDebit, a.totalCredit)
                a.lastBalance?.let {
                    Text(
                        (if (isCard) "Limit in last SMS " else "Balance in last SMS ") + inr0.format(it),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }
                Text(
                    if (expanded) "Tap to hide SMS" else "Tap to see SMS",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(top = 6.dp)
                )
            }

            if (expanded) {
                Column(Modifier.padding(horizontal = 16.dp).padding(bottom = 12.dp)) {
                    HorizontalDivider()
                    val list = if (largestFirst) a.txns.sortedByDescending { it.amount }
                    else a.txns.sortedByDescending { it.timeMillis }

                    list.take(limit).forEach { t ->
                        TxnRow(t, open = openTxn == t.uid) {
                            onOpenTxn(if (openTxn == t.uid) null else t.uid)
                        }
                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                    }
                    if (list.size > limit) {
                        TextButton(onClick = { limit += 30 }) { Text("Show more (${list.size - limit} left)") }
                    }
                }
            }
        }
    }
}

@Composable
private fun TxnRow(t: Txn, open: Boolean, onClick: () -> Unit) {
    val ctx = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val isOut = t.type == TxnType.DEBIT

    Column(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 8.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
            Column(Modifier.weight(1f)) {
                Text(
                    t.party ?: t.sender.ifBlank { "Bank SMS" },
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    "${dateFmt.format(Date(t.timeMillis))} · ${t.accountKind}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Text(
                (if (isOut) "- " else "+ ") + inr.format(t.amount),
                color = if (isOut) RED else GREEN,
                fontWeight = FontWeight.Medium,
                textAlign = TextAlign.End,
                maxLines = 1,
                softWrap = false,
                modifier = Modifier.padding(start = 12.dp).widthIn(min = 96.dp)
            )
        }

        if (open) {
            Surface(
                tonalElevation = 2.dp,
                shape = MaterialTheme.shapes.small,
                modifier = Modifier.fillMaxWidth().padding(top = 6.dp)
            ) {
                Column(Modifier.padding(10.dp)) {
                    Text("SMS from ${t.sender}", style = MaterialTheme.typography.labelSmall)
                    Spacer(Modifier.height(4.dp))
                    SelectionContainer { Text(t.raw, style = MaterialTheme.typography.bodyMedium) }
                    Row {
                        TextButton(onClick = { openSms(ctx, t) }) { Text("Open in Messages") }
                        TextButton(onClick = {
                            clipboard.setText(AnnotatedString(t.raw))
                            Toast.makeText(ctx, "SMS copied", Toast.LENGTH_SHORT).show()
                        }) { Text("Copy") }
                    }
                }
            }
        }
    }
}

/**
 * Best effort: Android has no standard way to jump to one exact SMS, so this opens the
 * conversation with the sender (or just the Messages app). The full text is always shown in-app.
 */
private fun openSms(ctx: Context, t: Txn) {
    val attempts = listOfNotNull(
        t.threadId.takeIf { it > 0 }?.let {
            Intent(Intent.ACTION_VIEW, Uri.parse("content://mms-sms/conversations/$it"))
        },
        Intent(Intent.ACTION_VIEW, Uri.parse("smsto:" + Uri.encode(t.sender))),
        Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MESSAGING)
    )
    for (intent in attempts) {
        try {
            ctx.startActivity(intent)
            return
        } catch (e: Exception) {
            // try the next option
        }
    }
    Toast.makeText(ctx, "Could not open the Messages app", Toast.LENGTH_SHORT).show()
}
