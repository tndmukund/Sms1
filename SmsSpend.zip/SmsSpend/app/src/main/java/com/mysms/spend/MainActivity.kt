package com.mysms.spend

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.KeyboardArrowLeft
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.NumberFormat
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SpendTheme {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    Box(Modifier.fillMaxSize().systemBarsPadding()) { App() }
                }
            }
        }
    }
}

private val inr: NumberFormat = NumberFormat.getCurrencyInstance(Locale("en", "IN"))
private val inr0: NumberFormat = NumberFormat.getCurrencyInstance(Locale("en", "IN")).apply {
    maximumFractionDigits = 0
    minimumFractionDigits = 0
}
private val dateFmt = SimpleDateFormat("dd MMM yy, hh:mm a", Locale.getDefault())
private val RED = Color(0xFFE5484D)
private val GREEN = Color(0xFF12A150)
private val AVATAR_COLORS = listOf(
    Color(0xFF4F46E5), Color(0xFF0EA5E9), Color(0xFF14B8A6),
    Color(0xFFF59E0B), Color(0xFFEC4899), Color(0xFF8B5CF6)
)

/** Whole rupees in lakh/crore grouping; very large amounts shown in crore. */
private fun money(v: Double): String =
    if (abs(v) >= 10_000_000.0)
        String.format(Locale.ENGLISH, "%s₹%.2f Cr", if (v < 0) "-" else "", abs(v) / 10_000_000.0)
    else inr0.format(v)

@Composable
fun App() {
    val ctx = LocalContext.current
    var granted by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_SMS) ==
                PackageManager.PERMISSION_GRANTED
        )
    }
    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted = it }

    if (!granted) {
        Column(
            Modifier.fillMaxSize().padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("SMS Spend", style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.height(12.dp))
            Text("This app reads your bank SMS on this phone only, to total your spends and credits. Nothing is uploaded.")
            Spacer(Modifier.height(20.dp))
            Button(onClick = { launcher.launch(Manifest.permission.READ_SMS) }) {
                Text("Allow SMS access")
            }
        }
        return
    }

    var data by remember { mutableStateOf<Pair<List<Txn>, List<Bill>>?>(null) }
    LaunchedEffect(Unit) {
        data = withContext(Dispatchers.IO) {
            val raw = SmsReader.readInbox(ctx)
            val t = SmsParser.parseAll(raw)
            t to SmsParser.parseBills(raw, t)
        }
    }

    val loaded = data
    if (loaded == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
    } else {
        SummaryScreen(loaded.first, loaded.second)
    }
}

@Composable
private fun SummaryScreen(all: List<Txn>, bills: List<Bill>) {
    val ctx = LocalContext.current
    var period by remember { mutableStateOf(Period.MONTH) }
    var periodIdx by remember { mutableStateOf(0) }          // 0 = latest period
    var query by remember { mutableStateOf("") }
    var typeFilter by remember { mutableStateOf<TxnType?>(null) }
    var largestFirst by remember { mutableStateOf(false) }
    var openAccount by remember { mutableStateOf<String?>(null) }
    var accountSel by remember { mutableStateOf<String?>(null) }   // null = all accounts / cards
    var vendorSel by remember { mutableStateOf<VendorTotal?>(null) }   // a vendor or a merged group, null = all
    var vendorGroups by remember { mutableStateOf(GroupStore.load(ctx)) }
    var editing by remember { mutableStateOf<GroupDraft?>(null) }
    var openTxn by remember { mutableStateOf<Long?>(null) }

    val accountKeys = remember(all) {
        all.groupBy { it.accountKey }.entries.sortedByDescending { it.value.size }.map { it.key }
    }
    val accountTxns = remember(all, accountSel) { all.filter { accountSel == null || it.accountKey == accountSel } }
    val allVendors = remember(all) { Periods.vendors(all) }
    val vendorList = remember(accountTxns, vendorGroups) {
        Periods.groupTotals(accountTxns, vendorGroups) + Periods.vendors(accountTxns)
    }
    val suggestions = remember(allVendors, vendorGroups) { Periods.suggestMerges(allVendors, vendorGroups) }
    val vendorName = vendorSel?.let { (if (it.isGroup) "★ " else "") + it.name }
    val filtered = remember(all, query, typeFilter, accountSel, vendorSel) {
        val vKeys = vendorSel?.keys
        all.filter {
            (accountSel == null || it.accountKey == accountSel) &&
                (vKeys == null || Periods.inKeys(it.party, vKeys)) &&
                (typeFilter == null || it.type == typeFilter) && Periods.matches(it, query)
        }
    }
    val groups = remember(filtered, period) { Periods.group(filtered, period) }
    val idx = periodIdx.coerceIn(0, maxOf(groups.size - 1, 0))
    val current = groups.getOrNull(idx)

    editing?.let { d ->
        MergeDialog(
            vendors = allVendors,
            draft = d,
            onSave = { name, keys ->
                val m = vendorGroups.toMutableMap()
                d.original?.let { m.remove(it) }
                m[name] = keys
                vendorGroups = m
                GroupStore.save(ctx, m)
                vendorSel = Periods.groupTotals(accountTxns, mapOf(name to keys)).firstOrNull()
                periodIdx = 0
                editing = null
            },
            onDelete = d.original?.let { orig ->
                {
                    val m = vendorGroups.toMutableMap()
                    m.remove(orig)
                    vendorGroups = m
                    GroupStore.save(ctx, m)
                    if (vendorSel?.name == orig) vendorSel = null
                    editing = null
                }
            },
            onDismiss = { editing = null }
        )
    }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Column(Modifier.padding(top = 4.dp)) {
                Text("SMS Spend", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Text(
                    "Your bank SMS, summed up on this phone",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        val shownBills = bills.filter {
            (accountSel == null || it.accountKey == accountSel) &&
                (it.dueDate == null || it.dueDate >= LocalDate.now().minusDays(45))
        }
        if (shownBills.isNotEmpty()) {
            item { BillsCard(shownBills, all) }
        }

        item {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it; openAccount = null; openTxn = null },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = MaterialTheme.colorScheme.surface,
                    unfocusedContainerColor = MaterialTheme.colorScheme.surface,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant
                ),
                label = { Text("Search SMS (zomato, 409, >5000)") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                trailingIcon = {
                    if (query.isNotEmpty()) {
                        IconButton(onClick = { query = "" }) {
                            Icon(Icons.Default.Close, contentDescription = "Clear")
                        }
                    }
                }
            )
        }

        // Filters as dropdowns (account one has a search box)
        item {
            FilterDropdown(
                label = "Card / account",
                valueText = accountSel ?: "All cards & accounts",
                options = listOf<String?>(null) + accountKeys,
                optionText = { it ?: "All cards & accounts" },
                searchable = true,
                onSelect = { accountSel = it; periodIdx = 0; openAccount = null; openTxn = null },
                modifier = Modifier.fillMaxWidth()
            )
        }
        item {
            FilterDropdown(
                label = "Vendor / merchant",
                valueText = vendorName ?: "All vendors",
                options = listOf<VendorTotal?>(null) + vendorList,
                optionText = {
                    if (it == null) "All vendors"
                    else (if (it.isGroup) "★ " else "") + "${it.name} · ${money(it.spent)}" +
                        (if (it.credited > 0) " (+${money(it.credited)})" else "") + " · ${it.count} SMS"
                },
                searchable = true,
                searchHint = "Search vendor e.g. zepto, ibis",
                onSelect = { vendorSel = it; periodIdx = 0; openAccount = null; openTxn = null },
                modifier = Modifier.fillMaxWidth()
            )
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                TextButton(onClick = {
                    editing = GroupDraft(null, "", vendorSel?.takeIf { !it.isGroup }?.keys ?: emptySet())
                }) { Text("+ Merge vendors into one") }
                val sel = vendorSel
                if (sel != null && sel.isGroup) {
                    TextButton(onClick = { editing = GroupDraft(sel.name, sel.name, sel.keys) }) { Text("Edit group") }
                }
            }
        }
        if (suggestions.isNotEmpty()) {
            item {
                Column(Modifier.fillMaxWidth()) {
                    Text(
                        "Looks like the same shop. Tap to merge:",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    suggestions.take(4).forEach { s ->
                        TextButton(onClick = {
                            val m = vendorGroups.toMutableMap()
                            m[s.name] = (m[s.name] ?: emptySet()) + s.keys
                            vendorGroups = m
                            GroupStore.save(ctx, m)
                        }) { Text("Merge ${s.name} (${s.names} names · ${s.count} SMS)") }
                    }
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterDropdown(
                    label = "Period",
                    valueText = period.title,
                    options = Period.values().toList(),
                    optionText = { it.title },
                    searchable = false,
                    onSelect = { period = it; periodIdx = 0; openAccount = null; openTxn = null },
                    modifier = Modifier.weight(1f)
                )
                FilterDropdown(
                    label = "Show",
                    valueText = when (typeFilter) { TxnType.DEBIT -> "Spent"; TxnType.CREDIT -> "Credited"; null -> "All" },
                    options = listOf<TxnType?>(null, TxnType.DEBIT, TxnType.CREDIT),
                    optionText = { when (it) { TxnType.DEBIT -> "Spent only"; TxnType.CREDIT -> "Credited only"; null -> "All" } },
                    searchable = false,
                    onSelect = { typeFilter = it; openAccount = null; openTxn = null },
                    modifier = Modifier.weight(1f)
                )
                FilterDropdown(
                    label = "Sort",
                    valueText = if (largestFirst) "Largest" else "Newest",
                    options = listOf(false, true),
                    optionText = { if (it) "Largest first" else "Newest first" },
                    searchable = false,
                    onSelect = { largestFirst = it },
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // < older   26 Oct – 1 Nov 2026   newer >
        if (period != Period.ALL && groups.isNotEmpty() && current != null) {
            item {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = { periodIdx = idx + 1; openAccount = null; openTxn = null },
                        enabled = idx < groups.size - 1
                    ) { Icon(Icons.Default.KeyboardArrowLeft, contentDescription = "Older") }
                    Text(
                        current.label,
                        modifier = Modifier.weight(1f),
                        textAlign = TextAlign.Center,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    IconButton(
                        onClick = { periodIdx = idx - 1; openAccount = null; openTxn = null },
                        enabled = idx > 0
                    ) { Icon(Icons.Default.KeyboardArrowRight, contentDescription = "Newer") }
                }
            }
        }

        if (current == null) {
            item { Text("No matching bank messages.") }
        } else {
            // Total for the selected period
            item {
                Box(
                    Modifier.fillMaxWidth()
                        .clip(RoundedCornerShape(24.dp))
                        .background(Brush.linearGradient(listOf(Color(0xFF4338CA), Color(0xFF7C3AED))))
                        .padding(20.dp)
                ) {
                    Column {
                        Text(
                            (accountSel ?: "All cards & accounts") + (vendorName?.let { " · $it" } ?: ""),
                            color = Color.White.copy(alpha = 0.85f),
                            style = MaterialTheme.typography.labelLarge,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            current.label,
                            color = Color.White,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(Modifier.height(14.dp))
                        val net = current.totalCredit - current.totalDebit
                        Text("Net", color = Color.White.copy(alpha = 0.75f), style = MaterialTheme.typography.labelMedium)
                        Text(
                            (if (net > 0) "+" else "") + money(net),
                            color = Color.White,
                            fontFamily = PoppinsFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 32.sp,
                            maxLines = 1,
                            softWrap = false
                        )
                        Spacer(Modifier.height(14.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            HeroStat("Spent", money(current.totalDebit), Color(0xFFFFB4B8), Modifier.weight(1f))
                            HeroStat("Credited", money(current.totalCredit), Color(0xFF86F0B2), Modifier.weight(1f))
                        }
                        Text(
                            "${current.count} SMS · ${current.accounts.size} accounts",
                            color = Color.White.copy(alpha = 0.7f),
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.padding(top = 12.dp)
                        )
                    }
                }
            }

            if (accountSel != null || vendorSel != null) {
                // Where the money went this period: by merchant, or member by member for a merged group
                val sv = vendorSel
                val isGroupView = sv != null && sv.isGroup
                val merchants = if (sv != null && sv.isGroup) {
                    val inPeriod = Periods.vendors(current.txns).associateBy { it.key }
                    sv.keys.map { k ->
                        val v = inPeriod[k]
                        MerchantTotal(
                            allVendors.firstOrNull { it.key == k }?.name ?: k,
                            v?.spent ?: 0.0, v?.credited ?: 0.0, v?.count ?: 0
                        )
                    }.sortedByDescending { it.spent }
                } else Periods.merchants(current.txns, merge = sv == null)
                item {
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp)) {
                            Text((if (isGroupView) "Group members" else "By merchant") + " · ${current.label}", fontWeight = FontWeight.SemiBold)
                            Spacer(Modifier.height(8.dp))
                            merchants.take(15).forEach { m ->
                                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                                    Column(Modifier.weight(1f)) {
                                        Text(m.name, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        Text(
                                            "${m.count} SMS",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    Column(horizontalAlignment = Alignment.End) {
                                        if (m.spent == 0.0 && m.credited == 0.0) Text("₹0", color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        if (m.spent > 0) Text("- " + inr.format(m.spent), color = RED, maxLines = 1, softWrap = false)
                                        if (m.credited > 0) Text("+ " + inr.format(m.credited), color = GREEN, maxLines = 1, softWrap = false)
                                    }
                                }
                                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                            }
                            if (merchants.size > 15) {
                                Text("+ ${merchants.size - 15} more merchants", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
                // Same card across all weeks / months: tap a row to jump to it
                if (period != Period.ALL) {
                    item {
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(16.dp)) {
                                Text("${period.title} history", fontWeight = FontWeight.SemiBold)
                                Spacer(Modifier.height(8.dp))
                                groups.forEachIndexed { i, g ->
                                    Row(
                                        Modifier.fillMaxWidth().clickable { periodIdx = i; openTxn = null }.padding(vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            g.label,
                                            modifier = Modifier.weight(1.3f),
                                            fontWeight = if (i == idx) FontWeight.Bold else FontWeight.Normal,
                                            style = MaterialTheme.typography.bodySmall
                                        )
                                        Text(money(g.totalDebit), color = RED, modifier = Modifier.weight(1f), textAlign = TextAlign.End, maxLines = 1, softWrap = false, style = MaterialTheme.typography.bodySmall)
                                        Text(money(g.totalCredit), color = GREEN, modifier = Modifier.weight(1f), textAlign = TextAlign.End, maxLines = 1, softWrap = false, style = MaterialTheme.typography.bodySmall)
                                    }
                                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                                }
                                Text(
                                    "Red = spent, green = credited",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(top = 6.dp)
                                )
                            }
                        }
                    }
                }
            }

            item {
                Text(
                    "By bank account",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }

            items(current.accounts, key = { it.key }) { a ->
                AccountCard(
                    a = a,
                    expanded = openAccount == a.key,
                    onToggle = { openAccount = if (openAccount == a.key) null else a.key; openTxn = null },
                    largestFirst = largestFirst,
                    openTxn = openTxn,
                    onOpenTxn = { openTxn = it }
                )
            }
        }
    }
}

/** A dropdown button; with [searchable] the menu starts with a search box. */
@Composable
private fun <T> FilterDropdown(
    label: String,
    valueText: String,
    options: List<T>,
    optionText: (T) -> String,
    searchable: Boolean,
    onSelect: (T) -> Unit,
    modifier: Modifier = Modifier,
    searchHint: String = "Search e.g. amex, hsbc, 7208"
) {
    var expanded by remember { mutableStateOf(false) }
    var q by remember { mutableStateOf("") }
    Box(modifier) {
        OutlinedButton(
            onClick = { expanded = true },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.outlinedButtonColors(containerColor = MaterialTheme.colorScheme.surface),
            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp)
        ) {
            Column(Modifier.weight(1f)) {
                Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(valueText, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
            }
            Icon(Icons.Default.ArrowDropDown, contentDescription = null)
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false; q = "" }) {
            if (searchable) {
                OutlinedTextField(
                    value = q,
                    onValueChange = { q = it },
                    singleLine = true,
                    placeholder = { Text(searchHint) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    modifier = Modifier.padding(horizontal = 8.dp).fillMaxWidth()
                )
            }
            val shown = options.filter { q.isBlank() || optionText(it).contains(q.trim(), ignoreCase = true) }
            if (shown.isEmpty()) {
                DropdownMenuItem(text = { Text("No match") }, onClick = {}, enabled = false)
            }
            shown.forEach { o ->
                DropdownMenuItem(
                    text = { Text(optionText(o)) },
                    onClick = { onSelect(o); expanded = false; q = "" }
                )
            }
        }
    }
}

private data class GroupDraft(val original: String?, val name: String, val keys: Set<String>)

/** Tick several vendor names (e.g. 3 POS machines of one shop) and save them as one named group. */
@Composable
private fun MergeDialog(
    vendors: List<VendorTotal>,
    draft: GroupDraft,
    onSave: (String, Set<String>) -> Unit,
    onDelete: (() -> Unit)?,
    onDismiss: () -> Unit
) {
    var name by remember { mutableStateOf(draft.name) }
    var picked by remember { mutableStateOf(draft.keys) }
    var q by remember { mutableStateOf("") }
    val initial = remember { draft.keys }   // vendors already in the group are listed first
    val shown = vendors
        .filter { q.isBlank() || it.name.contains(q.trim(), ignoreCase = true) }
        .sortedByDescending { it.key in initial }
    val sel = vendors.filter { it.key in picked }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (draft.original == null) "Merge vendors into one" else "Edit group") },
        text = {
            Column {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    singleLine = true,
                    label = { Text("Group name, e.g. Om Sai shop") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = q,
                    onValueChange = { q = it },
                    singleLine = true,
                    placeholder = { Text("Search vendors") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    "${sel.size} selected · spent ${money(sel.sumOf { it.spent })} · ${sel.sumOf { it.count }} SMS",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Medium
                )
                if (sel.isNotEmpty()) {
                    Text(
                        sel.joinToString(" + ") { it.name },
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 3,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                LazyColumn(Modifier.heightIn(max = 260.dp)) {
                    items(shown, key = { it.key }) { v ->
                        Row(
                            Modifier.fillMaxWidth()
                                .clickable { picked = if (v.key in picked) picked - v.key else picked + v.key }
                                .padding(vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(checked = v.key in picked, onCheckedChange = null)
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(v.name, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(
                                    "${v.count} SMS",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Text(money(v.spent), color = RED, maxLines = 1, softWrap = false)
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = name.isNotBlank() && picked.isNotEmpty(),
                onClick = { onSave(name.trim(), picked) }
            ) { Text("Save") }
        },
        dismissButton = {
            Row {
                if (onDelete != null) TextButton(onClick = onDelete) { Text("Delete", color = RED) }
                TextButton(onClick = onDismiss) { Text("Cancel") }
            }
        }
    )
}

/** Credit card bills from statement SMS, with due date and paid / overdue status. */
@Composable
private fun BillsCard(bills: List<Bill>, txns: List<Txn>) {
    val today = LocalDate.now()
    val fmt = DateTimeFormatter.ofPattern("d MMM yyyy", Locale.ENGLISH)
    // A card-bill payment received after the statement SMS means it was paid
    fun paid(b: Bill) = txns.any {
        it.accountKey == b.accountKey && it.type == TxnType.CREDIT &&
            it.party == "Card bill payment" && it.timeMillis > b.smsTime
    }
    val unpaid = bills.filter { !paid(it) }.sumOf { it.totalDue ?: it.minDue ?: 0.0 }

    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text("Credit card bills", fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.titleMedium)
            Text(
                "Unpaid: ${money(unpaid)}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(8.dp))
            bills.forEach { b ->
                val isPaid = paid(b)
                val days = b.dueDate?.let { ChronoUnit.DAYS.between(today, it) }
                val (status, color) = when {
                    isPaid -> "Paid" to GREEN
                    days == null -> "Due date not found" to MaterialTheme.colorScheme.onSurfaceVariant
                    days < 0 -> "Overdue ${-days} days" to RED
                    days == 0L -> "Due today" to RED
                    days <= 3 -> "Due in $days days" to Color(0xFFF59E0B)
                    else -> "Due in $days days" to MaterialTheme.colorScheme.onSurfaceVariant
                }
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Avatar(b.accountKey)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(b.accountKey, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            buildString {
                                b.totalDue?.let { append("Total ${money(it)}") }
                                b.minDue?.let { if (isNotEmpty()) append(" · "); append("Min ${money(it)}") }
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(status, color = color, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodySmall)
                        b.dueDate?.let {
                            Text(it.format(fmt), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun HeroStat(label: String, value: String, tint: Color, modifier: Modifier) {
    Column(
        modifier
            .clip(RoundedCornerShape(16.dp))
            .background(Color.White.copy(alpha = 0.14f))
            .padding(horizontal = 12.dp, vertical = 10.dp)
    ) {
        Text(label, color = Color.White.copy(alpha = 0.8f), style = MaterialTheme.typography.labelMedium)
        Text(
            value, color = tint, fontFamily = PoppinsFamily, fontWeight = FontWeight.Bold,
            fontSize = 17.sp, maxLines = 1, softWrap = false
        )
    }
}

/** Round coloured badge with the bank's first letter. */
@Composable
private fun Avatar(key: String) {
    val color = AVATAR_COLORS[(key.substringBefore(' ').hashCode() and 0x7fffffff) % AVATAR_COLORS.size]
    Box(
        Modifier.size(40.dp).clip(CircleShape).background(color),
        contentAlignment = Alignment.Center
    ) {
        Text(
            key.first().uppercase(),
            color = Color.White,
            fontFamily = PoppinsFamily,
            fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.titleMedium
        )
    }
}

/** Three equal columns: Spent | Credited | Net. Used for the total and for every account, so they line up. */
@Composable
private fun AmountCols(spent: Double, credited: Double) {
    val net = credited - spent
    Row(Modifier.fillMaxWidth()) {
        AmountCell("Spent", money(spent), RED, Modifier.weight(1f))
        AmountCell("Credited", money(credited), GREEN, Modifier.weight(1f))
        AmountCell(
            "Net",
            (if (net > 0) "+" else "") + money(net),
            if (net >= 0) GREEN else RED,
            Modifier.weight(1f)
        )
    }
}

@Composable
private fun AmountCell(label: String, value: String, color: Color, modifier: Modifier) {
    Column(modifier) {
        Text(
            label,
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            value,
            color = color,
            fontFamily = PoppinsFamily,
            fontWeight = FontWeight.SemiBold,
            style = MaterialTheme.typography.bodyMedium,
            maxLines = 1,
            softWrap = false
        )
    }
}

@Composable
private fun AccountCard(
    a: AccountSummary,
    expanded: Boolean,
    onToggle: () -> Unit,
    largestFirst: Boolean,
    openTxn: Long?,
    onOpenTxn: (Long?) -> Unit
) {
    var limit by remember(a.key) { mutableStateOf(30) }
    val isCard = a.key.contains("Credit Card")

    Card(Modifier.fillMaxWidth()) {
        Column {
            Column(Modifier.fillMaxWidth().clickable(onClick = onToggle).padding(16.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Avatar(a.key)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            a.key,
                            fontWeight = FontWeight.SemiBold,
                            style = MaterialTheme.typography.titleSmall,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            (if (isCard) "Credit card" else "Bank account") + " · ${a.count} SMS",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Spacer(Modifier.height(10.dp))
                AmountCols(a.totalDebit, a.totalCredit)
                a.lastBalance?.let {
                    Text(
                        (if (isCard) "Limit in last SMS " else "Balance in last SMS ") + inr0.format(it),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }
                Text(
                    if (expanded) "Tap to hide SMS" else "Tap to see SMS",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(top = 6.dp)
                )
            }

            if (expanded) {
                Column(Modifier.padding(horizontal = 16.dp).padding(bottom = 12.dp)) {
                    HorizontalDivider()
                    val list = if (largestFirst) a.txns.sortedByDescending { it.amount }
                    else a.txns.sortedByDescending { it.timeMillis }

                    list.take(limit).forEach { t ->
                        TxnRow(t, open = openTxn == t.uid) {
                            onOpenTxn(if (openTxn == t.uid) null else t.uid)
                        }
                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                    }
                    if (list.size > limit) {
                        TextButton(onClick = { limit += 30 }) { Text("Show more (${list.size - limit} left)") }
                    }
                }
            }
        }
    }
}

@Composable
private fun TxnRow(t: Txn, open: Boolean, onClick: () -> Unit) {
    val ctx = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val isOut = t.type == TxnType.DEBIT

    Column(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 8.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
            Column(Modifier.weight(1f)) {
                Text(
                    t.party ?: t.sender.ifBlank { "Bank SMS" },
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    "${dateFmt.format(Date(t.timeMillis))} · ${t.accountKind}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Text(
                (if (isOut) "- " else "+ ") + inr.format(t.amount),
                color = if (isOut) RED else GREEN,
                fontWeight = FontWeight.Medium,
                textAlign = TextAlign.End,
                maxLines = 1,
                softWrap = false,
                modifier = Modifier.padding(start = 12.dp).widthIn(min = 96.dp)
            )
        }

        if (open) {
            Surface(
                tonalElevation = 2.dp,
                shape = MaterialTheme.shapes.small,
                modifier = Modifier.fillMaxWidth().padding(top = 6.dp)
            ) {
                Column(Modifier.padding(10.dp)) {
                    Text("SMS from ${t.sender}", style = MaterialTheme.typography.labelSmall)
                    Spacer(Modifier.height(4.dp))
                    SelectionContainer { Text(t.raw, style = MaterialTheme.typography.bodyMedium) }
                    Row {
                        TextButton(onClick = { openSms(ctx, t) }) { Text("Open in Messages") }
                        TextButton(onClick = {
                            clipboard.setText(AnnotatedString(t.raw))
                            Toast.makeText(ctx, "SMS copied", Toast.LENGTH_SHORT).show()
                        }) { Text("Copy") }
                    }
                }
            }
        }
    }
}

/**
 * Best effort: Android has no standard way to jump to one exact SMS, so this opens the
 * conversation with the sender (or just the Messages app). The full text is always shown in-app.
 */
private fun openSms(ctx: Context, t: Txn) {
    val attempts = listOfNotNull(
        t.threadId.takeIf { it > 0 }?.let {
            Intent(Intent.ACTION_VIEW, Uri.parse("content://mms-sms/conversations/$it"))
        },
        Intent(Intent.ACTION_VIEW, Uri.parse("smsto:" + Uri.encode(t.sender))),
        Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MESSAGING)
    )
    for (intent in attempts) {
        try {
            ctx.startActivity(intent)
            return
        } catch (e: Exception) {
            // try the next option
        }
    }
    Toast.makeText(ctx, "Could not open the Messages app", Toast.LENGTH_SHORT).show()
}
