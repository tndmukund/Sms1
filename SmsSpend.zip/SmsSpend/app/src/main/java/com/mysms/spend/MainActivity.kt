package com.mysms.spend

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.KeyboardArrowLeft
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Surface(Modifier.fillMaxSize()) { App() } } }
    }
}

private val inr: NumberFormat = NumberFormat.getCurrencyInstance(Locale("en", "IN"))
private val inr0: NumberFormat = NumberFormat.getCurrencyInstance(Locale("en", "IN")).apply {
    maximumFractionDigits = 0
    minimumFractionDigits = 0
}
private val dateFmt = SimpleDateFormat("dd MMM yy, hh:mm a", Locale.getDefault())
private val RED = Color(0xFFC62828)
private val GREEN = Color(0xFF2E7D32)

/** Whole rupees in lakh/crore grouping; very large amounts shown in crore. */
private fun money(v: Double): String =
    if (abs(v) >= 10_000_000.0)
        String.format(Locale.ENGLISH, "%s₹%.2f Cr", if (v < 0) "-" else "", abs(v) / 10_000_000.0)
    else inr0.format(v)

@Composable
fun App() {
    val ctx = LocalContext.current
    var granted by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_SMS) ==
                PackageManager.PERMISSION_GRANTED
        )
    }
    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted = it }

    if (!granted) {
        Column(
            Modifier.fillMaxSize().padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("SMS Spend", style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.height(12.dp))
            Text("This app reads your bank SMS on this phone only, to total your spends and credits. Nothing is uploaded.")
            Spacer(Modifier.height(20.dp))
            Button(onClick = { launcher.launch(Manifest.permission.READ_SMS) }) {
                Text("Allow SMS access")
            }
        }
        return
    }

    var all by remember { mutableStateOf<List<Txn>?>(null) }
    LaunchedEffect(Unit) {
        all = withContext(Dispatchers.IO) { SmsParser.parseAll(SmsReader.readInbox(ctx)) }
    }

    val txns = all
    if (txns == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
    } else {
        SummaryScreen(txns)
    }
}

@Composable
private fun SummaryScreen(all: List<Txn>) {
    var period by remember { mutableStateOf(Period.MONTH) }
    var periodIdx by remember { mutableStateOf(0) }          // 0 = latest period
    var query by remember { mutableStateOf("") }
    var typeFilter by remember { mutableStateOf<TxnType?>(null) }
    var largestFirst by remember { mutableStateOf(false) }
    var openAccount by remember { mutableStateOf<String?>(null) }
    var accountSel by remember { mutableStateOf<String?>(null) }   // null = all accounts / cards
    var openTxn by remember { mutableStateOf<Long?>(null) }

    val accountKeys = remember(all) {
        all.groupBy { it.accountKey }.entries.sortedByDescending { it.value.size }.map { it.key }
    }
    val filtered = remember(all, query, typeFilter, accountSel) {
        all.filter {
            (accountSel == null || it.accountKey == accountSel) &&
                (typeFilter == null || it.type == typeFilter) && Periods.matches(it, query)
        }
    }
    val groups = remember(filtered, period) { Periods.group(filtered, period) }
    val idx = periodIdx.coerceIn(0, maxOf(groups.size - 1, 0))
    val current = groups.getOrNull(idx)

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text("Account summary", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        }

        item {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it; openAccount = null; openTxn = null },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                label = { Text("Search SMS (zomato, 409, >5000)") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                trailingIcon = {
                    if (query.isNotEmpty()) {
                        IconButton(onClick = { query = "" }) {
                            Icon(Icons.Default.Close, contentDescription = "Clear")
                        }
                    }
                }
            )
        }

        // Pick one card / account (or all)
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item {
                    FilterChip(
                        selected = accountSel == null,
                        onClick = { accountSel = null; periodIdx = 0; openAccount = null; openTxn = null },
                        label = { Text("All cards & accounts") }
                    )
                }
                items(accountKeys) { k ->
                    FilterChip(
                        selected = accountSel == k,
                        onClick = { accountSel = k; periodIdx = 0; openAccount = null; openTxn = null },
                        label = { Text(k) }
                    )
                }
            }
        }

        // Weekly / Monthly / Yearly / All time
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(Period.values().toList()) { p ->
                    FilterChip(
                        selected = period == p,
                        onClick = { period = p; periodIdx = 0; openAccount = null; openTxn = null },
                        label = { Text(p.title) }
                    )
                }
            }
        }

        // < older   26 Oct – 1 Nov 2026   newer >
        if (period != Period.ALL && groups.isNotEmpty() && current != null) {
            item {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = { periodIdx = idx + 1; openAccount = null; openTxn = null },
                        enabled = idx < groups.size - 1
                    ) { Icon(Icons.Default.KeyboardArrowLeft, contentDescription = "Older") }
                    Text(
                        current.label,
                        modifier = Modifier.weight(1f),
                        textAlign = TextAlign.Center,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    IconButton(
                        onClick = { periodIdx = idx - 1; openAccount = null; openTxn = null },
                        enabled = idx > 0
                    ) { Icon(Icons.Default.KeyboardArrowRight, contentDescription = "Newer") }
                }
            }
        }

        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item { FilterChip(selected = typeFilter == null, onClick = { typeFilter = null }, label = { Text("All") }) }
                item { FilterChip(selected = typeFilter == TxnType.DEBIT, onClick = { typeFilter = TxnType.DEBIT }, label = { Text("Spent only") }) }
                item { FilterChip(selected = typeFilter == TxnType.CREDIT, onClick = { typeFilter = TxnType.CREDIT }, label = { Text("Credited only") }) }
                item { FilterChip(selected = largestFirst, onClick = { largestFirst = !largestFirst }, label = { Text("Largest first") }) }
            }
        }

        if (current == null) {
            item { Text("No matching bank messages.") }
        } else {
            // Total for the selected period
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Total · ${current.label}", fontWeight = FontWeight.SemiBold)
                        Text(
                            "${current.count} SMS · ${current.accounts.size} accounts",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(Modifier.height(10.dp))
                        AmountCols(current.totalDebit, current.totalCredit)
                    }
                }
            }

            if (accountSel != null) {
                // Where the money went this period, by merchant
                val merchants = Periods.merchants(current.txns)
                item {
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp)) {
                            Text("By merchant · ${current.label}", fontWeight = FontWeight.SemiBold)
                            Spacer(Modifier.height(8.dp))
                            merchants.take(15).forEach { m ->
                                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                                    Column(Modifier.weight(1f)) {
                                        Text(m.name, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        Text(
                                            "${m.count} SMS",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    Column(horizontalAlignment = Alignment.End) {
                                        if (m.spent > 0) Text("- " + inr.format(m.spent), color = RED, maxLines = 1, softWrap = false)
                                        if (m.credited > 0) Text("+ " + inr.format(m.credited), color = GREEN, maxLines = 1, softWrap = false)
                                    }
                                }
                                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                            }
                            if (merchants.size > 15) {
                                Text("+ ${merchants.size - 15} more merchants", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
                // Same card across all weeks / months: tap a row to jump to it
                if (period != Period.ALL) {
                    item {
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(16.dp)) {
                                Text("${period.title} history", fontWeight = FontWeight.SemiBold)
                                Spacer(Modifier.height(8.dp))
                                groups.forEachIndexed { i, g ->
                                    Row(
                                        Modifier.fillMaxWidth().clickable { periodIdx = i; openTxn = null }.padding(vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            g.label,
                                            modifier = Modifier.weight(1.3f),
                                            fontWeight = if (i == idx) FontWeight.Bold else FontWeight.Normal,
                                            style = MaterialTheme.typography.bodySmall
                                        )
                                        Text(money(g.totalDebit), color = RED, modifier = Modifier.weight(1f), textAlign = TextAlign.End, maxLines = 1, softWrap = false, style = MaterialTheme.typography.bodySmall)
                                        Text(money(g.totalCredit), color = GREEN, modifier = Modifier.weight(1f), textAlign = TextAlign.End, maxLines = 1, softWrap = false, style = MaterialTheme.typography.bodySmall)
                                    }
                                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                                }
                                Text(
                                    "Red = spent, green = credited",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(top = 6.dp)
                                )
                            }
                        }
                    }
                }
            }

            item {
                Text(
                    "By bank account",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }

            items(current.accounts, key = { it.key }) { a ->
                AccountCard(
                    a = a,
                    expanded = openAccount == a.key,
                    onToggle = { openAccount = if (openAccount == a.key) null else a.key; openTxn = null },
                    largestFirst = largestFirst,
                    openTxn = openTxn,
                    onOpenTxn = { openTxn = it }
                )
            }
        }
    }
}

/** Three equal columns: Spent | Credited | Net. Used for the total and for every account, so they line up. */
@Composable
private fun AmountCols(spent: Double, credited: Double) {
    val net = credited - spent
    Row(Modifier.fillMaxWidth()) {
        AmountCell("Spent", money(spent), RED, Modifier.weight(1f))
        AmountCell("Credited", money(credited), GREEN, Modifier.weight(1f))
        AmountCell(
            "Net",
            (if (net > 0) "+" else "") + money(net),
            if (net >= 0) GREEN else RED,
            Modifier.weight(1f)
        )
    }
}

@Composable
private fun AmountCell(label: String, value: String, color: Color, modifier: Modifier) {
    Column(modifier) {
        Text(
            label,
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            value,
            color = color,
            fontWeight = FontWeight.SemiBold,
            style = MaterialTheme.typography.bodyMedium,
            maxLines = 1,
            softWrap = false
        )
    }
}

@Composable
private fun AccountCard(
    a: AccountSummary,
    expanded: Boolean,
    onToggle: () -> Unit,
    largestFirst: Boolean,
    openTxn: Long?,
    onOpenTxn: (Long?) -> Unit
) {
    var limit by remember(a.key) { mutableStateOf(30) }
    val isCard = a.key.contains("Credit Card")

    Card(Modifier.fillMaxWidth()) {
        Column {
            Column(Modifier.fillMaxWidth().clickable(onClick = onToggle).padding(16.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        a.key,
                        modifier = Modifier.weight(1f),
                        fontWeight = FontWeight.SemiBold,
                        style = MaterialTheme.typography.titleSmall
                    )
                    Text(
                        "${a.count} SMS",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(Modifier.height(10.dp))
                AmountCols(a.totalDebit, a.totalCredit)
                a.lastBalance?.let {
                    Text(
                        (if (isCard) "Limit in last SMS " else "Balance in last SMS ") + inr0.format(it),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }
                Text(
                    if (expanded) "Tap to hide SMS" else "Tap to see SMS",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(top = 6.dp)
                )
            }

            if (expanded) {
                Column(Modifier.padding(horizontal = 16.dp).padding(bottom = 12.dp)) {
                    HorizontalDivider()
                    val list = if (largestFirst) a.txns.sortedByDescending { it.amount }
                    else a.txns.sortedByDescending { it.timeMillis }

                    list.take(limit).forEach { t ->
                        TxnRow(t, open = openTxn == t.uid) {
                            onOpenTxn(if (openTxn == t.uid) null else t.uid)
                        }
                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                    }
                    if (list.size > limit) {
                        TextButton(onClick = { limit += 30 }) { Text("Show more (${list.size - limit} left)") }
                    }
                }
            }
        }
    }
}

@Composable
private fun TxnRow(t: Txn, open: Boolean, onClick: () -> Unit) {
    val ctx = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val isOut = t.type == TxnType.DEBIT

    Column(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 8.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
            Column(Modifier.weight(1f)) {
                Text(
                    t.party ?: t.sender.ifBlank { "Bank SMS" },
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    "${dateFmt.format(Date(t.timeMillis))} · ${t.accountKind}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Text(
                (if (isOut) "- " else "+ ") + inr.format(t.amount),
                color = if (isOut) RED else GREEN,
                fontWeight = FontWeight.Medium,
                textAlign = TextAlign.End,
                maxLines = 1,
                softWrap = false,
                modifier = Modifier.padding(start = 12.dp).widthIn(min = 96.dp)
            )
        }

        if (open) {
            Surface(
                tonalElevation = 2.dp,
                shape = MaterialTheme.shapes.small,
                modifier = Modifier.fillMaxWidth().padding(top = 6.dp)
            ) {
                Column(Modifier.padding(10.dp)) {
                    Text("SMS from ${t.sender}", style = MaterialTheme.typography.labelSmall)
                    Spacer(Modifier.height(4.dp))
                    SelectionContainer { Text(t.raw, style = MaterialTheme.typography.bodyMedium) }
                    Row {
                        TextButton(onClick = { openSms(ctx, t) }) { Text("Open in Messages") }
                        TextButton(onClick = {
                            clipboard.setText(AnnotatedString(t.raw))
                            Toast.makeText(ctx, "SMS copied", Toast.LENGTH_SHORT).show()
                        }) { Text("Copy") }
                    }
                }
            }
        }
    }
}

/**
 * Best effort: Android has no standard way to jump to one exact SMS, so this opens the
 * conversation with the sender (or just the Messages app). The full text is always shown in-app.
 */
private fun openSms(ctx: Context, t: Txn) {
    val attempts = listOfNotNull(
        t.threadId.takeIf { it > 0 }?.let {
            Intent(Intent.ACTION_VIEW, Uri.parse("content://mms-sms/conversations/$it"))
        },
        Intent(Intent.ACTION_VIEW, Uri.parse("smsto:" + Uri.encode(t.sender))),
        Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MESSAGING)
    )
    for (intent in attempts) {
        try {
            ctx.startActivity(intent)
            return
        } catch (e: Exception) {
            // try the next option
        }
    }
    Toast.makeText(ctx, "Could not open the Messages app", Toast.LENGTH_SHORT).show()
}
