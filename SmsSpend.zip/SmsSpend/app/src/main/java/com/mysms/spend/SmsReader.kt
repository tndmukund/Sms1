package com.mysms.spend

import android.content.Context
import android.provider.Telephony

object SmsReader {

    /** Reads inbox messages newer than [sinceMillis] (default: last ~3 years, so yearly totals make sense). */
    fun readInbox(
        context: Context,
        sinceMillis: Long = System.currentTimeMillis() - 3L * 365 * 24 * 60 * 60 * 1000
    ): List<RawSms> {
        val out = ArrayList<RawSms>()
        val cursor = context.contentResolver.query(
            Telephony.Sms.Inbox.CONTENT_URI,
            arrayOf(
                Telephony.Sms._ID,
                Telephony.Sms.THREAD_ID,
                Telephony.Sms.ADDRESS,
                Telephony.Sms.BODY,
                Telephony.Sms.DATE
            ),
            "${Telephony.Sms.DATE} >= ?",
            arrayOf(sinceMillis.toString()),
            "${Telephony.Sms.DATE} DESC"
        ) ?: return out

        cursor.use {
            val iId = it.getColumnIndexOrThrow(Telephony.Sms._ID)
            val iThread = it.getColumnIndexOrThrow(Telephony.Sms.THREAD_ID)
            val iAddr = it.getColumnIndexOrThrow(Telephony.Sms.ADDRESS)
            val iBody = it.getColumnIndexOrThrow(Telephony.Sms.BODY)
            val iDate = it.getColumnIndexOrThrow(Telephony.Sms.DATE)
            while (it.moveToNext()) {
                out += RawSms(
                    sender = it.getString(iAddr) ?: "",
                    body = it.getString(iBody) ?: "",
                    timeMillis = it.getLong(iDate),
                    id = it.getLong(iId),
                    threadId = it.getLong(iThread)
                )
            }
        }
        return out
    }
}
