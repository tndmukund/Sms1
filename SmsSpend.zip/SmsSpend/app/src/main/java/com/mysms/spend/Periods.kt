package com.mysms.spend

import java.time.DayOfWeek
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.temporal.TemporalAdjusters
import java.util.Locale

enum class Period(val title: String) {
    WEEK("Weekly"), MONTH("Monthly"), YEAR("Yearly"), ALL("All time")
}

data class PeriodSummary(
    val key: String,
    val label: String,
    val start: LocalDate,
    val totalDebit: Double,
    val totalCredit: Double,
    val txns: List<Txn>,
    val accounts: List<AccountSummary>
) {
    val count: Int get() = txns.size
    val net: Double get() = totalCredit - totalDebit
}

data class VendorTotal(
    val key: String,
    val name: String,
    val spent: Double,
    val credited: Double,
    val count: Int,
    val keys: Set<String> = setOf(key),   // vendor keys this row covers (several for a merged group)
    val isGroup: Boolean = false
)

data class MerchantTotal(val name: String, val spent: Double, val credited: Double, val count: Int)

/** A ready-made "these look like the same shop" suggestion the user can accept with one tap. */
data class MergeSuggestion(val name: String, val keys: Set<String>, val names: Int, val count: Int, val spent: Double)

/** Weekly / monthly / yearly grouping and search. Pure Kotlin, unit tested. */
object Periods {

    /** First day of the week (Monday), month or year that contains [timeMillis]. */
    fun startOf(timeMillis: Long, period: Period, zone: ZoneId = ZoneId.systemDefault()): LocalDate {
        val d = Instant.ofEpochMilli(timeMillis).atZone(zone).toLocalDate()
        return when (period) {
            Period.WEEK -> d.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
            Period.MONTH -> d.withDayOfMonth(1)
            Period.YEAR -> d.withDayOfYear(1)
            Period.ALL -> LocalDate.of(2000, 1, 1)
        }
    }

    fun label(start: LocalDate, period: Period): String = when (period) {
        Period.ALL -> "All time"
        Period.YEAR -> start.year.toString()
        Period.MONTH -> start.format(DateTimeFormatter.ofPattern("MMMM yyyy", Locale.ENGLISH))
        Period.WEEK -> {
            val end = start.plusDays(6)
            val f = DateTimeFormatter.ofPattern("d MMM", Locale.ENGLISH)
            "${start.format(f)} – ${end.format(f)} ${end.year}"
        }
    }

    fun group(
        txns: List<Txn>,
        period: Period,
        zone: ZoneId = ZoneId.systemDefault()
    ): List<PeriodSummary> =
        txns.groupBy { startOf(it.timeMillis, period, zone) }
            .map { (start, items) ->
                PeriodSummary(
                    key = "${period.name}-$start",
                    label = label(start, period),
                    start = start,
                    totalDebit = items.filter { it.type == TxnType.DEBIT }.sumOf { it.amount },
                    totalCredit = items.filter { it.type == TxnType.CREDIT }.sumOf { it.amount },
                    txns = items,
                    accounts = SmsParser.summarize(items)
                )
            }
            .sortedByDescending { it.start }

    /**
     * Same-shop key: banks cut names ("IBIS BENGALU" / "IBIS BENGALURU") and UPI ids add "@bank",
     * so compare only the first 8 letters/digits of the name before any "@".
     */
    fun vendorKey(party: String?): String? = Brands.keyFor(party) ?: legacyKey(party)

    /** The older key (first 8 letters). Kept so groups saved by earlier versions still work. */
    fun legacyKey(party: String?): String? {
        val p = party?.substringBefore('@')?.uppercase(Locale.ENGLISH)?.filter { it.isLetterOrDigit() }
        return p?.takeIf { it.length >= 3 }?.take(8)
    }

    /** True when this merchant belongs to a group's key set (new or old style key). */
    fun inKeys(party: String?, keys: Set<String>): Boolean {
        val a = vendorKey(party)
        val b = legacyKey(party)
        return (a != null && a in keys) || (b != null && b in keys)
    }

    /** All vendors with their totals, biggest spend first. Longest spelling is used as the display name. */
    fun vendors(txns: List<Txn>): List<VendorTotal> =
        txns.mapNotNull { t -> vendorKey(t.party)?.let { it to t } }
            .groupBy({ it.first }, { it.second })
            .map { (key, items) ->
                VendorTotal(
                    key = key,
                    name = Brands.nameOf(key) ?: items.mapNotNull { it.party?.trim() }.maxByOrNull { it.length } ?: key,
                    spent = items.filter { it.type == TxnType.DEBIT }.sumOf { it.amount },
                    credited = items.filter { it.type == TxnType.CREDIT }.sumOf { it.amount },
                    count = items.size
                )
            }
            .sortedWith(compareByDescending<VendorTotal> { it.spent }.thenByDescending { it.credited })

    private val stopWords = setOf(
        "CREDIT", "DEBIT", "PAYMENT", "TRANSFER", "ACCOUNT", "PRIVATE", "LIMITED", "SUPER", "STORE",
        "STORES", "SHREE", "SHRI", "TRADERS", "ENTERPRISES", "SERVICES", "SERVICE", "BANK", "WALLET", "UPI"
    )

    /**
     * Vendors that start with the same word (e.g. "Anukri Stores" and "Anukri Mart") are probably one shop.
     * Returns one-tap suggestions for names that are not already in a group.
     */
    fun suggestMerges(vendors: List<VendorTotal>, groups: Map<String, Set<String>>): List<MergeSuggestion> {
        val used = groups.values.flatten().toSet()
        return vendors
            .filter { !it.key.startsWith(Brands.PREFIX) && it.key !in used }
            .mapNotNull { v ->
                val w = v.name.split(Regex("[^A-Za-z]+")).firstOrNull { it.isNotEmpty() }?.uppercase(Locale.ENGLISH)
                if (w != null && w.length >= 5 && w !in stopWords) w to v else null
            }
            .groupBy({ it.first }, { it.second })
            .filter { it.value.size >= 2 }
            .map { (w, list) ->
                MergeSuggestion(
                    name = w.lowercase(Locale.ENGLISH).replaceFirstChar { it.uppercase() },
                    keys = list.map { it.key }.toSet(),
                    names = list.size,
                    count = list.sumOf { it.count },
                    spent = list.sumOf { it.spent }
                )
            }
            .sortedByDescending { it.spent }
    }

    /** Totals for user-made groups such as "Om Sai shop" = several POS machine names. */
    fun groupTotals(txns: List<Txn>, groups: Map<String, Set<String>>): List<VendorTotal> =
        groups.map { (name, keys) ->
            val items = txns.filter { inKeys(it.party, keys) }
            VendorTotal(
                key = "group:$name",
                name = name,
                spent = items.filter { it.type == TxnType.DEBIT }.sumOf { it.amount },
                credited = items.filter { it.type == TxnType.CREDIT }.sumOf { it.amount },
                count = items.size,
                keys = keys,
                isGroup = true
            )
        }.sortedByDescending { it.spent }

    /** Per-merchant totals (biggest spend first). Missing merchant names are grouped as "Unknown". */
    fun merchants(txns: List<Txn>, merge: Boolean = true): List<MerchantTotal> =
        txns.groupBy {
            val raw = it.party?.trim()?.takeIf { p -> p.isNotEmpty() } ?: "Unknown"
            (if (merge) Brands.keyFor(raw) else null) ?: raw.uppercase(Locale.ENGLISH)
        }
            .map { (name, items) ->
                MerchantTotal(
                    name = Brands.nameOf(name) ?: items.firstNotNullOfOrNull { it.party?.trim()?.takeIf { p -> p.isNotEmpty() } } ?: "Unknown",
                    spent = items.filter { it.type == TxnType.DEBIT }.sumOf { it.amount },
                    credited = items.filter { it.type == TxnType.CREDIT }.sumOf { it.amount },
                    count = items.size
                )
            }
            .sortedWith(compareByDescending<MerchantTotal> { it.spent }.thenByDescending { it.credited })

    /**
     * Search across SMS text, merchant, bank, card/account digits and amount.
     * Words are ANDed. Use ">5000" or "<500" to filter by amount, e.g. "zomato >300".
     */
    fun matches(t: Txn, query: String): Boolean {
        val tokens = query.trim().lowercase().split(Regex("\\s+")).filter { it.isNotEmpty() }
        if (tokens.isEmpty()) return true

        val hay = buildString {
            append(t.raw.lowercase()).append(' ')
            append(t.sender.lowercase()).append(' ')
            append(t.bank.lowercase()).append(' ')
            append(t.accountKind.lowercase()).append(' ')
            t.last4?.let { append(it).append(' ') }
            t.party?.let { append(it.lowercase()).append(' ') }
            append(String.format(Locale.ENGLISH, "%.2f", t.amount)).append(' ')
            append(t.amount.toLong())
        }

        return tokens.all { tok ->
            val num = tok.drop(1).replace(",", "").toDoubleOrNull()
            when {
                tok == ">" || tok == "<" -> true // still typing
                tok.startsWith(">") && num != null -> t.amount > num
                tok.startsWith("<") && num != null -> t.amount < num
                else -> hay.contains(tok.replace(",", ""))
            }
        }
    }
}
