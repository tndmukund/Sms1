package com.mysms.spend

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Saves your vendor groups on this phone only. */
object GroupStore {
    private const val PREF = "vendor_groups"

    fun load(ctx: Context): Map<String, Set<String>> {
        val out = LinkedHashMap<String, Set<String>>()
        try {
            val o = JSONObject(ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString("json", "{}") ?: "{}")
            for (name in o.keys()) {
                val a = o.getJSONArray(name)
                out[name] = (0 until a.length()).map { a.getString(it) }.toSet()
            }
        } catch (e: Exception) {
            // corrupted data: start empty
        }
        return out
    }

    fun save(ctx: Context, groups: Map<String, Set<String>>) {
        val o = JSONObject()
        groups.forEach { (name, keys) -> o.put(name, JSONArray(keys.toList())) }
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString("json", o.toString()).apply()
    }
}
