package com.mysms.spend

import android.content.Context
import android.print.PrintAttributes
import android.print.PrintManager
import android.webkit.WebView
import android.webkit.WebViewClient
import java.text.NumberFormat
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

/** Builds a clean printable report and sends it to the phone's print screen (printer or "Save as PDF"). */
object Report {

    private val inr: NumberFormat = NumberFormat.getCurrencyInstance(Locale("en", "IN"))
    private val dateFmt: DateTimeFormatter = DateTimeFormatter.ofPattern("d MMM yyyy, h:mm a", Locale.ENGLISH)

    private fun money(v: Double) = inr.format(v)

    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

    /**
     * @param periods when given, a table with one line per period is added (the "all periods" report)
     */
    fun build(
        subtitle: String,
        periodLabel: String,
        txns: List<Txn>,
        periods: List<PeriodSummary>?,
        mergeMerchants: Boolean
    ): String {
        val spent = txns.filter { it.type == TxnType.DEBIT }.sumOf { it.amount }
        val credited = txns.filter { it.type == TxnType.CREDIT }.sumOf { it.amount }
        val net = credited - spent
        val sb = StringBuilder()
        sb.append(
            """<html><head><meta charset="utf-8"><style>
            body{font-family:sans-serif;color:#111;font-size:12px;margin:0}
            h1{font-size:20px;margin:0 0 4px 0}
            h2{font-size:14px;margin:22px 0 6px 0;border-bottom:2px solid #4338CA;padding-bottom:3px}
            .sub{color:#555;margin-bottom:10px}
            table{width:100%;border-collapse:collapse}
            th{text-align:left;background:#eef;padding:5px;font-size:11px}
            td{padding:4px 5px;border-bottom:1px solid #ddd;vertical-align:top}
            tr{page-break-inside:avoid}
            thead{display:table-header-group}
            .r{text-align:right;white-space:nowrap}
            .red{color:#C62828}.green{color:#2E7D32}
            .box{display:inline-block;margin-right:18px;padding:8px 12px;border:1px solid #ccc;border-radius:6px}
            .box b{display:block;font-size:16px}
            .small{color:#777;font-size:10px;margin-top:20px}
            </style></head><body>"""
        )
        sb.append("<h1>Spend report</h1>")
        sb.append("<div class='sub'>").append(esc(subtitle)).append(" &middot; ").append(esc(periodLabel)).append("</div>")
        sb.append("<div class='box'>Spent<b class='red'>").append(money(spent)).append("</b></div>")
        sb.append("<div class='box'>Credited<b class='green'>").append(money(credited)).append("</b></div>")
        sb.append("<div class='box'>Net<b>").append(money(net)).append("</b></div>")
        sb.append("<div class='box'>Messages<b>").append(txns.size).append("</b></div>")

        if (periods != null && periods.size > 1) {
            sb.append("<h2>Period by period</h2><table><thead><tr><th>Period</th><th class='r'>Spent</th><th class='r'>Credited</th><th class='r'>Net</th></tr></thead><tbody>")
            periods.forEach { p ->
                sb.append("<tr><td>").append(esc(p.label)).append("</td><td class='r red'>").append(money(p.totalDebit))
                    .append("</td><td class='r green'>").append(money(p.totalCredit))
                    .append("</td><td class='r'>").append(money(p.totalCredit - p.totalDebit)).append("</td></tr>")
            }
            sb.append("</tbody></table>")
        }

        val accounts = SmsParser.summarize(txns)
        if (accounts.size > 1) {
            sb.append("<h2>By card / account</h2><table><thead><tr><th>Account</th><th class='r'>Spent</th><th class='r'>Credited</th><th class='r'>SMS</th></tr></thead><tbody>")
            accounts.forEach { a ->
                sb.append("<tr><td>").append(esc(a.key)).append("</td><td class='r red'>").append(money(a.totalDebit))
                    .append("</td><td class='r green'>").append(money(a.totalCredit))
                    .append("</td><td class='r'>").append(a.count).append("</td></tr>")
            }
            sb.append("</tbody></table>")
        }

        val merchants = Periods.merchants(txns, mergeMerchants).take(30)
        if (merchants.isNotEmpty()) {
            sb.append("<h2>By merchant</h2><table><thead><tr><th>Merchant</th><th class='r'>Spent</th><th class='r'>Credited</th><th class='r'>SMS</th></tr></thead><tbody>")
            merchants.forEach { m ->
                sb.append("<tr><td>").append(esc(m.name)).append("</td><td class='r red'>").append(money(m.spent))
                    .append("</td><td class='r green'>").append(money(m.credited))
                    .append("</td><td class='r'>").append(m.count).append("</td></tr>")
            }
            sb.append("</tbody></table>")
        }

        sb.append("<h2>All transactions</h2><table><thead><tr><th>Date</th><th>Account</th><th>Merchant</th><th class='r'>Amount</th></tr></thead><tbody>")
        txns.sortedByDescending { it.timeMillis }.forEach { t ->
            val date = Instant.ofEpochMilli(t.timeMillis).atZone(ZoneId.systemDefault()).format(dateFmt)
            val debit = t.type == TxnType.DEBIT
            sb.append("<tr><td>").append(esc(date)).append("</td><td>").append(esc(t.accountKey))
                .append("</td><td>").append(esc(t.party ?: "-"))
                .append("</td><td class='r ").append(if (debit) "red'>- " else "green'>+ ")
                .append(money(t.amount)).append("</td></tr>")
        }
        sb.append("</tbody></table>")
        sb.append("<div class='small'>Made on this phone from your bank SMS. Nothing was uploaded.</div></body></html>")
        return sb.toString()
    }

    /** Opens the phone's print screen. There you can pick a printer or choose "Save as PDF". */
    fun print(ctx: Context, jobName: String, html: String) {
        val web = WebView(ctx)
        var started = false
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String?) {
                if (started) return
                started = true
                val pm = ctx.getSystemService(Context.PRINT_SERVICE) as PrintManager
                pm.print(jobName, view.createPrintDocumentAdapter(jobName), PrintAttributes.Builder().build())
            }
        }
        web.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null)
    }
}
