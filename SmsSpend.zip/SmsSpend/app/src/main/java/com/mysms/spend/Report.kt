package com.mysms.spend

import android.content.Context
import android.print.PrintAttributes
import android.print.PrintManager
import android.webkit.WebView
import android.webkit.WebViewClient
import java.text.NumberFormat
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

/** Builds a printable report that looks like the app (colour header, cards, weekly / monthly / yearly) and sends it to the print screen. */
object Report {

    private val inr2: NumberFormat = NumberFormat.getCurrencyInstance(Locale("en", "IN"))
    private val inr0: NumberFormat = NumberFormat.getCurrencyInstance(Locale("en", "IN")).apply {
        maximumFractionDigits = 0
        minimumFractionDigits = 0
    }
    private val dateFmt: DateTimeFormatter = DateTimeFormatter.ofPattern("dd MMM yy, hh:mm a", Locale.ENGLISH)
    private val palette = listOf("#8B5CF6", "#4F46E5", "#0EA5E9", "#F97316", "#10B981", "#EC4899")

    private fun m0(v: Double) = inr0.format(v)
    private fun m2(v: Double) = inr2.format(v)
    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

    private fun historyCard(title: String, period: Period, all: List<Txn>, limit: Int): String {
        val rows = Periods.group(all, period).take(limit)
        if (rows.isEmpty()) return ""
        val sb = StringBuilder()
        sb.append("<div class='card'><div class='h'>").append(esc(title)).append("</div>")
        rows.forEachIndexed { i, p ->
            sb.append("<div class='row line'><div class='grow").append(if (i == 0) " bold" else "").append("'>")
                .append(esc(p.label)).append("</div><div class='amt red'>").append(m0(p.totalDebit))
                .append("</div><div class='amt green'>").append(m0(p.totalCredit)).append("</div></div>")
        }
        sb.append("<div class='muted small'>Red = spent, green = credited</div></div>")
        return sb.toString()
    }

    /**
     * @param periodTxns the transactions shown in detail (one period, or everything)
     * @param allTxns everything that matches the filters, used for the weekly / monthly / yearly history
     */
    fun build(
        subtitle: String,
        periodLabel: String,
        periodTxns: List<Txn>,
        allTxns: List<Txn>,
        mergeMerchants: Boolean
    ): String {
        val spent = periodTxns.filter { it.type == TxnType.DEBIT }.sumOf { it.amount }
        val credited = periodTxns.filter { it.type == TxnType.CREDIT }.sumOf { it.amount }
        val net = credited - spent
        val accounts = SmsParser.summarize(periodTxns)
        val sb = StringBuilder()
        sb.append(
            """<html><head><meta charset="utf-8"><style>
            *{box-sizing:border-box;-webkit-print-color-adjust:exact;print-color-adjust:exact}
            body{font-family:Roboto,sans-serif;color:#111827;font-size:13px;margin:0;padding:0;background:#fff}
            .hero{background:linear-gradient(135deg,#4338CA,#7C3AED);background-color:#5B3BD8;color:#fff;border-radius:22px;padding:20px 22px;page-break-inside:avoid}
            .hero .l{opacity:.85;font-size:12px}
            .hero .p{font-size:17px;font-weight:bold;margin-top:2px}
            .hero .n{font-size:34px;font-weight:bold;margin:12px 0 2px 0}
            .tiles{display:flex;margin-top:12px}
            .tile{flex:1;background:rgba(255,255,255,.18);background-color:#7456E0;border-radius:16px;padding:10px 14px}
            .tile+.tile{margin-left:12px}
            .tile .t{opacity:.85;font-size:12px}
            .tile b{display:block;font-size:20px;margin-top:2px}
            .spent{color:#FFB4B4}.cred{color:#7CF0B0}
            .card{background:#fff;border:1px solid #E5E7EB;border-radius:20px;padding:16px 18px;margin-top:16px}
            .h{font-size:16px;font-weight:bold;margin-bottom:8px}
            .sect{font-size:18px;font-weight:bold;margin:22px 0 0 2px}
            .row{display:flex;align-items:center;page-break-inside:avoid}
            .line{padding:9px 0;border-bottom:1px solid #E5E7EB}
            .grow{flex:1;padding-right:10px}
            .amt{text-align:right;white-space:nowrap;min-width:90px}
            .bold{font-weight:bold}
            .red{color:#E5484D}.green{color:#12A150}
            .muted{color:#6B7280}.small{font-size:11px;margin-top:8px}
            .av{width:42px;height:42px;border-radius:21px;color:#fff;font-weight:bold;font-size:18px;text-align:center;line-height:42px;margin-right:12px}
            .stats{display:flex;margin:10px 0 6px 0}
            .stats div{flex:1}
            .stats b{display:block;font-size:17px;margin-top:2px}
            .big{font-size:14px}
            .foot{color:#9CA3AF;font-size:10px;margin-top:22px}
            </style></head><body>"""
        )

        // Header card, like the app
        sb.append("<div class='hero'><div class='l'>").append(esc(subtitle)).append("</div>")
            .append("<div class='p'>").append(esc(periodLabel)).append("</div>")
            .append("<div class='l' style='margin-top:12px'>Net</div><div class='n'>")
            .append(if (net > 0) "+" else "").append(m0(net)).append("</div>")
            .append("<div class='tiles'><div class='tile'><div class='t'>Spent</div><b class='spent'>").append(m0(spent))
            .append("</b></div><div class='tile'><div class='t'>Credited</div><b class='cred'>").append(m0(credited))
            .append("</b></div></div><div class='l' style='margin-top:12px'>")
            .append(periodTxns.size).append(" SMS · ").append(accounts.size).append(" accounts</div></div>")

        // Where the money went
        val merchants = Periods.merchants(periodTxns, mergeMerchants).take(15)
        if (merchants.isNotEmpty()) {
            sb.append("<div class='card'><div class='h'>By merchant · ").append(esc(periodLabel)).append("</div>")
            merchants.forEach { mt ->
                sb.append("<div class='row line'><div class='grow'><div class='big'>").append(esc(mt.name))
                    .append("</div><div class='muted small' style='margin:0'>").append(mt.count).append(" SMS</div></div><div class='amt'>")
                if (mt.spent > 0) sb.append("<div class='red'>- ").append(m2(mt.spent)).append("</div>")
                if (mt.credited > 0) sb.append("<div class='green'>+ ").append(m2(mt.credited)).append("</div>")
                if (mt.spent == 0.0 && mt.credited == 0.0) sb.append("<div class='muted'>").append(m2(0.0)).append("</div>")
                sb.append("</div></div>")
            }
            sb.append("</div>")
        }

        // Weekly, monthly and yearly in one report
        sb.append(historyCard("Weekly history", Period.WEEK, allTxns, 12))
        sb.append(historyCard("Monthly history", Period.MONTH, allTxns, 24))
        sb.append(historyCard("Yearly history", Period.YEAR, allTxns, 10))

        // One card per bank account / credit card, with its SMS list
        if (accounts.isNotEmpty()) {
            sb.append("<div class='sect'>By bank account</div>")
            accounts.forEach { a ->
                val color = palette[Math.abs(a.key.hashCode()) % palette.size]
                val kind = if (a.key.contains("Credit Card")) "Credit card" else "Bank account"
                val n = a.totalCredit - a.totalDebit
                sb.append("<div class='card'><div class='row'><div class='av' style='background:").append(color).append("'>")
                    .append(esc(a.key.take(1).uppercase(Locale.ENGLISH))).append("</div><div class='grow'><div class='bold big'>")
                    .append(esc(a.key)).append("</div><div class='muted'>").append(kind).append(" · ").append(a.count)
                    .append(" SMS</div></div></div>")
                sb.append("<div class='stats'><div><span class='muted'>Spent</span><b class='red'>").append(m0(a.totalDebit))
                    .append("</b></div><div><span class='muted'>Credited</span><b class='green'>").append(m0(a.totalCredit))
                    .append("</b></div><div><span class='muted'>Net</span><b class='").append(if (n >= 0) "green'>+" else "red'>")
                    .append(m0(n)).append("</b></div></div>")
                a.txns.sortedByDescending { it.timeMillis }.forEach { t ->
                    val date = Instant.ofEpochMilli(t.timeMillis).atZone(ZoneId.systemDefault()).format(dateFmt)
                        .replace("AM", "am").replace("PM", "pm")
                    val debit = t.type == TxnType.DEBIT
                    sb.append("<div class='row line'><div class='grow'><div class='big'>").append(esc(t.party ?: "-"))
                        .append("</div><div class='muted small' style='margin:0'>").append(esc(date)).append(" · ")
                        .append(esc(t.accountKind)).append("</div></div><div class='amt ")
                        .append(if (debit) "red'>- " else "green'>+ ").append(m2(t.amount)).append("</div></div>")
                }
                sb.append("</div>")
            }
        }

        sb.append("<div class='foot'>Made on this phone from your bank SMS. Nothing was uploaded.</div></body></html>")
        return sb.toString()
    }

    /** Opens the phone's print screen. There you can pick a printer or choose "Save as PDF". */
    fun print(ctx: Context, jobName: String, html: String) {
        val web = WebView(ctx)
        var started = false
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String?) {
                if (started) return
                started = true
                val pm = ctx.getSystemService(Context.PRINT_SERVICE) as PrintManager
                val attrs = PrintAttributes.Builder()
                    .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                    .setMinMargins(PrintAttributes.Margins(400, 400, 400, 400))
                    .build()
                pm.print(jobName, view.createPrintDocumentAdapter(jobName), attrs)
            }
        }
        web.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null)
    }
}
