package com.mysms.spend

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.unit.dp

/** Inter for reading text, Poppins for headings and money. Both support the ₹ sign. */
val InterFamily = FontFamily(
    Font(R.font.inter_regular, FontWeight.Normal),
    Font(R.font.inter_medium, FontWeight.Medium),
    Font(R.font.inter_semibold, FontWeight.SemiBold),
    Font(R.font.inter_semibold, FontWeight.Bold)
)
val PoppinsFamily = FontFamily(
    Font(R.font.poppins_medium, FontWeight.Normal),
    Font(R.font.poppins_medium, FontWeight.Medium),
    Font(R.font.poppins_bold, FontWeight.SemiBold),
    Font(R.font.poppins_bold, FontWeight.Bold)
)

private val base = Typography()
private val AppTypography = Typography(
    headlineMedium = base.headlineMedium.copy(fontFamily = PoppinsFamily),
    headlineSmall = base.headlineSmall.copy(fontFamily = PoppinsFamily),
    titleLarge = base.titleLarge.copy(fontFamily = PoppinsFamily),
    titleMedium = base.titleMedium.copy(fontFamily = PoppinsFamily),
    titleSmall = base.titleSmall.copy(fontFamily = InterFamily),
    bodyLarge = base.bodyLarge.copy(fontFamily = InterFamily),
    bodyMedium = base.bodyMedium.copy(fontFamily = InterFamily),
    bodySmall = base.bodySmall.copy(fontFamily = InterFamily),
    labelLarge = base.labelLarge.copy(fontFamily = InterFamily),
    labelMedium = base.labelMedium.copy(fontFamily = InterFamily),
    labelSmall = base.labelSmall.copy(fontFamily = InterFamily)
)

private val LightColors = lightColorScheme(
    primary = Color(0xFF4F46E5),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE0E7FF),
    onPrimaryContainer = Color(0xFF1E1B6B),
    background = Color(0xFFF3F4FA),
    onBackground = Color(0xFF111827),
    surface = Color.White,
    onSurface = Color(0xFF111827),
    surfaceVariant = Color.White,          // cards
    onSurfaceVariant = Color(0xFF667085),
    surfaceTint = Color.White,
    surfaceContainer = Color.White,
    surfaceContainerHigh = Color.White,
    surfaceContainerHighest = Color.White,
    outline = Color(0xFFC9CEDD),
    outlineVariant = Color(0xFFE6E8F0)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFFA5B4FC),
    onPrimary = Color(0xFF1E1B6B),
    primaryContainer = Color(0xFF3730A3),
    onPrimaryContainer = Color(0xFFE0E7FF),
    background = Color(0xFF0E1120),
    onBackground = Color(0xFFE8EAF2),
    surface = Color(0xFF171B2D),
    onSurface = Color(0xFFE8EAF2),
    surfaceVariant = Color(0xFF171B2D),
    onSurfaceVariant = Color(0xFF9AA3B8),
    surfaceTint = Color(0xFF171B2D),
    surfaceContainer = Color(0xFF171B2D),
    surfaceContainerHigh = Color(0xFF171B2D),
    surfaceContainerHighest = Color(0xFF171B2D),
    outline = Color(0xFF3A4260),
    outlineVariant = Color(0xFF262C45)
)

@Composable
fun SpendTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) DarkColors else LightColors,
        typography = AppTypography,
        shapes = Shapes(
            small = RoundedCornerShape(10.dp),
            medium = RoundedCornerShape(20.dp),
            large = RoundedCornerShape(24.dp)
        ),
        content = content
    )
}
